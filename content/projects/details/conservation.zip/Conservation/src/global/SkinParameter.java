package global;

import java.awt.Color;

//Ƥ���������ԣ�Need For Complete
public class SkinParameter {
	public static Color itemTitle = new Color(26, 105, 173);
	public static Color itemContent = new Color(56, 155, 233);
	public static Color playerMusicName = new Color(26, 105, 173);
	public static Color playerMusicLength = new Color(56, 155, 233);
	public static Color photoUploaderTitle = new Color(26, 105, 173);
	public static Color photoUploaderContent = new Color(56, 155, 233);
	public static Color photoViewerTitle = new Color(26, 105, 173);
	public static Color photoViewerContent = new Color(56, 155, 233);
	public static Color photoFrameBackground = Color.black;
}
