package global;

import java.awt.Color;
import java.io.Serializable;
/**
 * ��־��
 * @author Song Renchu
 */
@SuppressWarnings("serial")
public class Article implements Serializable{
	//���塢�ֺš�������ʽ��������ɫ��������ɫ����־���⡢��־����
	public String fontName;
	public int fontSize;
	public boolean bold,italic;
	public Color color,backColor;
	public String title;
	public String content;
	public Authority authority;
	
	public Article(){}
	/**
	 * ���췽��
	 * @param fontName
	 * @param fontSize 
	 * @param bold
	 * @param italic
	 * @param color
	 * @param backColor
	 * @param title
	 * @param content
	 */
	public Article(String fontName, int fontSize, boolean bold, boolean italic, Color color, Color backColor, String title, String content, Authority authority) {
		this.fontName = fontName;
		this.fontSize = fontSize;
		this.bold = bold;
		this.italic = italic;
		this.color = color;
		this.backColor = backColor;
		this.title = title;
		this.content = content;
		this.authority = authority;
	}
	public void updateArticle(Article other) {
		this.fontName = other.fontName;
		this.fontSize = other.fontSize;
		this.bold = other.bold;
		this.italic = other.italic;
		this.color = other.color;
		this.backColor = other.backColor;
		this.title = other.title;
		this.content = other.content;
		this.authority = other.authority;
	}

}
