package trans;

import global.Article;
import global.Authority;
import global.ItemType;
import global.TransType;
import global.Transaction;
import global.Video;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.media.Manager;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;

import ui.MainFrame;
import ui.VideoPlayer;
//������Ƶ�����Ĵ�����
@SuppressWarnings({ "unused", "restriction" })
public class VideoMonitor implements Runnable{
	public static ArrayList<Video> videoList = null;
	public static VideoPlayer videoPlayer = null;
	
	//�����ļ�ʱ��
	public Video video;
	public String fromPath;
	
	//��ʼ����Ƶ�б�
	public static void initVideoList() {
		if (videoList == null) {
			videoList = new ArrayList<Video>();
			String path=System.getProperty("user.dir")+"/content/list_video";
			try {
				ObjectInputStream rw =new ObjectInputStream(new FileInputStream(path));
				while (true) {
					try {
						Video video = (Video)rw.readObject();
						if (video == null) break;
						File testVideo = new File(video.getFileName());
						if (testVideo.exists()){ videoList.add(video);
						}
					}catch (Exception e) {
						break;
					}
				}
				rw.close();
			}catch (Exception e){}
		}
	}
	
	//����һ����Ƶ
	public void addVideo() {
		//���ӵ��б�
		videoList.add(video);
		//System.out.println(videoList.size());
		//�����ļ�
		try {
			//�ο�http://blog.csdn.net/ta8210/article/details/2073817
			  int length=20000000;
			  FileInputStream in=new FileInputStream(new File(fromPath));
			  ProgressMonitorInputStream inputProgress = new ProgressMonitorInputStream(null, "���ڿ�����Ƶ�ļ�", in);
			  ProgressMonitor p = inputProgress.getProgressMonitor();
			  FileOutputStream out=new FileOutputStream(new File(video.getFileName()));
			  byte[] buffer=new byte[length];
			  while(true){
			   int ins=inputProgress.read(buffer);
			   if(ins==-1){
			    in.close();
			    out.flush();
			    out.close();
			    break;
			   }else
			    out.write(buffer,0,ins);
			  }
		}catch(Exception e){}
		//����ǹ�������Ƶ����Ҫ�ϴ�������
		if (video.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.add, ItemType.video, video.getFileName(), video.getVideoName(), video.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
	}
	
	//ɾ��һ����Ƶ
	public static void deleteVideo(int i) {
		//����ǹ�����Ƶ����Ҫɾ������������Ƶ
		Video video = videoList.get(i);
		if (video.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.delete, ItemType.video, video.getFileName(),video.getVideoName(), video.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
		//ɾ�����ظ���
		File toDel = new File(video.getFileName());
		if (toDel.isFile()) toDel.delete();
		//�ڴ�ͬ��
		videoList.remove(i);
	}
	
	//��Ƶ�޸�Ȩ��
	public static void changeVideoAuthority(int i) {
		Video video = videoList.get(i);
		if (video.getAuthority() == Authority.isPrivate)
			video.setAnthority(Authority.isPublic);
		else
			video.setAnthority(Authority.isPrivate);
		TransMonitor newTrans = new TransMonitor(new Transaction(TransType.changeAuthority, ItemType.video, video.getFileName(),video.getVideoName(), video.getAuthority(), -1));
		newTrans.setName("�洢����");
		try {
			newTrans.start();
		}catch (Exception e) {}
	}
	
	//��ȡһ����Ƶ�ļ���
	public static String newFileName(String ext) {
		return System.getProperty("user.dir")+"/content/video/" + String.valueOf(System.currentTimeMillis())+"."+ext;
	}
	
	//����Ƶ�б�д�ش���
	public static void writeBack() {
		if (videoList != null){
			try {
				String path=System.getProperty("user.dir")+"/content/list_video";
				ObjectOutputStream rw =new ObjectOutputStream(new FileOutputStream(path));
				for (int i = 0; i < videoList.size(); ++i) {
					rw.writeObject(videoList.get(i));
				}
				rw.close();
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "��Ƶ�б�����ʱ������������", "����", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	//������Ƶ
	public static void playVideo(int i) {
		videoPlayer = new VideoPlayer();
		videoPlayer.path = videoList.get(i).getFileName();
		Thread viewerTrd = new Thread(videoPlayer);
		viewerTrd.start();
	}
	
	//����Զ����Ƶ
	public static void playVideo(String path) {
		videoPlayer = new VideoPlayer();
		videoPlayer.path = path;
		Thread viewerTrd = new Thread(videoPlayer);
		viewerTrd.start();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		addVideo();
		MainFrame.resetMainBoard();
	}
}
