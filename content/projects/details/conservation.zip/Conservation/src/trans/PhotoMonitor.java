package trans;

import global.Article;
import global.Authority;
import global.ItemType;
import global.Photo;
import global.TransType;
import global.Transaction;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;

import ui.MainFrame;
import ui.PhotoViewer;
//������Ƭ�����Ĵ�����
@SuppressWarnings("unused")
public class PhotoMonitor implements Runnable{
	public static ArrayList<Photo> photoList = null;
	//public static ArrayList<Boolean> photoDeleted = null;
	public static PhotoViewer photoViewer = null;
	
	//�����ļ�ʱ��
	public Photo photo;
	public String fromPath;
	
	//��ʼ����Ƭ�б�
	public static void initPhotoList() {
		if (photoList == null) {
			photoList = new ArrayList<Photo>();
			//photoDeleted = new ArrayList<Boolean>();
			String path=System.getProperty("user.dir")+"/content/list_photo";
			//System.out.println("123");
			//String pathPhoto=System.getProperty("user.dir")+"/content/photo/";
			try {
				ObjectInputStream rw =new ObjectInputStream(new FileInputStream(path));
				//System.out.println("123");
				while (true) {
					try {
						Photo photo = (Photo)rw.readObject();
						//System.out.println("123");
						if (photo == null) break;
						//System.out.println("456");
						File testPhoto = new File(photo.getFileName());
						//System.out.println("789");
						if (testPhoto.exists()){ 
							photoList.add(photo);
							//photoDeleted.add(false);
							//System.out.println("29292929");
						}
						//System.out.println("101112");
					}catch (Exception e) {
						//System.out.println(e);
						break;
					}
				}
				rw.close();
			}catch (Exception e){}
		}
	}
	
	//����һ����Ƭ
	public void addPhoto() {
		//���ӵ��б�
		photoList.add(photo);
		//photoDeleted.add(false);
		//System.out.println(photoList.size());
		//�����ļ�
		FileOutputStream out = null;
		try {
			//�ο�http://blog.csdn.net/ta8210/article/details/2073817
			  int length=20000000;
			  FileInputStream in=new FileInputStream(new File(fromPath));
			  ProgressMonitorInputStream inputProgress = new ProgressMonitorInputStream(null, "���ڿ�����Ƭ�ļ�", in);
			  ProgressMonitor p = inputProgress.getProgressMonitor();
			  out=new FileOutputStream(new File(photo.getFileName()));
			  byte[] buffer=new byte[length];
			  while(true){
			   int ins=inputProgress.read(buffer);
			   if(ins==-1){
			    in.close();
			    out.flush();
			    out.close();
			    break;
			   }else
			    out.write(buffer,0,ins);
			  }
		}catch(Exception e){}
		finally {
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//����ǹ�������Ƭ����Ҫ�ϴ�������
		if (photo.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.add, ItemType.photo, photo.getFileName(), photo.getPhotoName(), photo.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
		
		JOptionPane.showMessageDialog(null, "ͼƬ�ļ�������ɣ�", "���", JOptionPane.PLAIN_MESSAGE);
	}
	
	//ɾ��һ����Ƭ
	public static void deletePhoto(int i) {
		//����ǹ�����Ƭ����Ҫɾ������������Ƭ
		Photo photo = photoList.get(i);
		if (photo.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.delete, ItemType.photo, photo.getFileName(), photo.getPhotoName(),photo.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
		//ɾ�����ظ���
		System.out.println(photo.getFileName());
		File toDel = new File(photo.getFileName());
		try {
			for (int ii = 0; ii<10000; ++ii)
				toDel.delete();
		}catch (Exception e) {
			System.out.println(e);
		}
		//�ڴ�ͬ��
		photoList.remove(i);
		//photoDeleted.set(i, true);
	}
	
	//��Ƭ�޸�Ȩ��
	public static void changePhotoAuthority(int i) {
		Photo photo = photoList.get(i);
		if (photo.getAuthority() == Authority.isPrivate)
			photo.setAnthority(Authority.isPublic);
		else
			photo.setAnthority(Authority.isPrivate);
		TransMonitor newTrans = new TransMonitor(new Transaction(TransType.changeAuthority, ItemType.photo, photo.getFileName(), photo.getPhotoName(),photo.getAuthority(), -1));
		newTrans.setName("�洢����");
		try {
			newTrans.start();
		}catch (Exception e) {}
	}
	
	//��ȡһ����Ƭ�ļ���
	public static String newFileName(String ext) {
		return System.getProperty("user.dir")+"/content/photo/" + String.valueOf(System.currentTimeMillis())+"."+ext;
	}
	
	//����Ƭ�б�д�ش���
	public static void writeBack() {
		if (photoList != null){
			try {
				String path=System.getProperty("user.dir")+"/content/list_photo";
				ObjectOutputStream rw =new ObjectOutputStream(new FileOutputStream(path));
				for (int i = 0; i < photoList.size(); ++i){
						rw.writeObject(photoList.get(i));
					}
				rw.close();
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "��Ƭ�б�����ʱ������������", "����", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	//  ��ʾ��Ƭ
	public static void viewPhoto(int i) {
		if (photoViewer == null) photoViewer = new PhotoViewer();
		photoViewer.photoIndex = i;
		photoViewer.showPhoto();
		//photoViewer.setVisible(true);
		Thread viewerTrd = new Thread(photoViewer);
		viewerTrd.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		addPhoto();
		MainFrame.resetMainBoard();
	}
}
