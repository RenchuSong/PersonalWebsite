package trans;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import javax.swing.JOptionPane;

//import ui.UIUniversal;

@SuppressWarnings("serial")
class UserInfo implements Serializable{
	private int userId;
	private String userName, userPassword, userIntroduction;
	private boolean userGender;
	private boolean isModified;
	
	/**
	 * Construct
	 * @param userName
	 * @param userPassword
	 * @param userIntroduction
	 * @param userGender
	 */
	public UserInfo(String userName, String userPassword, String userIntroduction, boolean userGender) {
		this.userId = -1;
		this.userGender = userGender;
		this.userIntroduction = userIntroduction;
		this.userName = userName;
		this.userPassword = userPassword;
		this.isModified = true;
	}
	/**
	 * Get UserId
	 * @return userId
	 */
	public int getId() {
		return userId;
	}
	/**
	 * Get Username
	 * @return userName
	 */
	public String getName() {
		return userName;
	}
	/**
	 * Get Password
	 * @return userPassword
	 */
	public String getPassword() {
		return userPassword;
	}
	/**
	 * Get Introduction
	 * @return userIntroduction
	 */
	public String getIntroduction() {
		return userIntroduction;
	}
	/**
	 * get Gender
	 * @return If the user is a girl
	 */
	public boolean isGirl() {
		return userGender;
	}
	/**
	 * Change User Information
	 * @param newName
	 * @param newPassword
	 * @param newIntroduction
	 * @param newGender
	 */
	public void changeUserInfo(String newName, String newPassword, String newIntroduction, boolean newGender) {
		if (newName!=null) userName = newName;
		if (newPassword!=null) userPassword = newPassword;
		if (newIntroduction!=null) userIntroduction = newIntroduction;
		userGender = newGender;
		this.isModified = true;
		//Need Send to Server Here
	}
	/**
	 * If User Account Modified
	 * @return
	 */
	public boolean getModified() {
		return this.isModified;
	}
	
	/**
	 * Set UserId got From Server
	 * @param id
	 */
	public void setId(int id) {
		this.userId = id;
	}
	/**
	 * After Asychornized to Server, Set modified = false, Meaning Server Symchronization completed
	 */
	public void completeModified() {
		this.isModified = false;
	}
}

public class Account {
	public static UserInfo user;
	/**
	 * Init Account From Local Disk
	 */
	public static void initAccount() {
		File file = new File(System.getProperty("user.dir")+"/config/cache_account");
		try {
			ObjectInputStream readAccount =new ObjectInputStream(new FileInputStream(file));
			user = (UserInfo)readAccount.readObject();
			//user.setId(22);
			readAccount.close();
		}catch (Exception e) {
			user = null;
		}
	}
	/**
	 * Write Back Account Status to Disk
	 */
	public static void saveAccount() {
		File file = new File(System.getProperty("user.dir")+"/config/cache_account");
		try {
			ObjectOutputStream writeAccount =new ObjectOutputStream(new FileOutputStream(file));
			writeAccount.writeObject(user);
			writeAccount.close();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null, "�洢ʧ��", "����", JOptionPane.ERROR_MESSAGE);
		}
	}
}
