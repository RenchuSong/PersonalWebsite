package trans;

import global.Article;
import global.Authority;
import global.ItemType;
import global.TransType;
import global.Transaction;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;
//�������²����Ĵ�����
public class ArticleMonitor {
	public static ArrayList<String> articleList;
	public static ArrayList<Article> articleItemList;
	
	//��ʼ�����������б�
	public static void initArticleList() {
		String path=System.getProperty("user.dir")+"/content/article/";
        File articlePath=new File(path);
        articleList=new ArrayList<String>();
        File[] articles = articlePath.listFiles();
        for (int i=0; i<articles.length; ++i)
        	articleList.add(articles[i].getAbsolutePath());
        //for(int i=0;i<articleList.size();i++)
        //     System.out.println(articleList.get(i).getAbsolutePath());
	}
	
	//�����������£�
	public static void loadArticle() {
		if (articleItemList == null)
			articleItemList = new ArrayList<Article>();
		else articleItemList.clear();
		
		for (int i = 0; i<articleList.size(); ) {
			Article article;
			try {
				ObjectInputStream rw =new ObjectInputStream(new FileInputStream(articleList.get(i)));
				article = (Article)rw.readObject();
				rw.close();
				articleItemList.add(article);
				++i;
			}catch (Exception e) {
				System.out.println(e.toString());
				JOptionPane.showMessageDialog(null, "��־:"+articleList.get(i)+"�𻵣�����־����ɾ����", "����", JOptionPane.ERROR_MESSAGE);
				File toDel = new File(articleList.get(i));
				if (toDel.isFile()) toDel.delete();
				articleList.remove(i);
			}
		}
	}
	
	//����һƪ����
	public static void addArticle(String fileName) {
		articleList.add(fileName);
	}
	
	//��ȡһ�������µ��ļ���
	public static String newFileName() {
		return System.getProperty("user.dir")+"/content/article/" + String.valueOf(System.currentTimeMillis())+".docu";
	}
	
	//ɾ��һƪ����
	public static void deleteArticle(int i) {
		//����ǹ��еģ��������������ɾ������
		if (articleItemList.get(i).authority == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.delete, ItemType.article, articleList.get(i),articleItemList.get(i).title, articleItemList.get(i).authority, -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
		//ɾ�����صĸ���
		File toDel = new File(articleList.get(i));
		if (toDel.isFile()) toDel.delete();
		articleList.remove(i);
		articleItemList.remove(i);
	}
	
}
