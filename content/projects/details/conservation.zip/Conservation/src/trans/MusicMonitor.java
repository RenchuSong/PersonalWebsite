package trans;

import global.Article;
import global.Authority;
import global.ItemType;
import global.Music;
import global.TransType;
import global.Transaction;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;

import ui.MainFrame;
import ui.MusicPlayer;
//�������ֲ����Ĵ�����
@SuppressWarnings("unused")
public class MusicMonitor implements Runnable{
	public static ArrayList<Music> musicList = null;
	public static MusicPlayer musicPlayer = null;
	
	//�����ļ�ʱ��
	public Music music;
	public String fromPath;
	
	//��ʼ�������б�
	public static void initMusicList() {
		if (musicList == null) {
			musicList = new ArrayList<Music>();
			String path=System.getProperty("user.dir")+"/content/list_music";
			//System.out.println("123");
			//String pathMusic=System.getProperty("user.dir")+"/content/music/";
			try {
				ObjectInputStream rw =new ObjectInputStream(new FileInputStream(path));
				//System.out.println("123");
				while (true) {
					try {
						Music music = (Music)rw.readObject();
						//System.out.println("123");
						if (music == null) break;
						//System.out.println("456");
						File testMusic = new File(music.getFileName());
						//System.out.println("789");
						if (testMusic.exists()){ musicList.add(music);
							//System.out.println("29292929");
						}
						//System.out.println("101112");
					}catch (Exception e) {
						//System.out.println(e);
						break;
					}
				}
				rw.close();
			}catch (Exception e){}
		}
	}
	
	//����һ������
	public void addMusic() {
		//���ӵ��б�
		musicList.add(music);
		//System.out.println(musicList.size());
		//�����ļ�
		try {
			//�ο�http://blog.csdn.net/ta8210/article/details/2073817
			  int length=20000000;
			  FileInputStream in=new FileInputStream(new File(fromPath));
			  ProgressMonitorInputStream inputProgress = new ProgressMonitorInputStream(null, "���ڿ��������ļ�", in);
			  ProgressMonitor p = inputProgress.getProgressMonitor();
			  FileOutputStream out=new FileOutputStream(new File(music.getFileName()));
			  byte[] buffer=new byte[length];
			  while(true){
			   int ins=inputProgress.read(buffer);
			   if(ins==-1){
			    in.close();
			    out.flush();
			    out.close();
			    break;
			   }else
			    out.write(buffer,0,ins);
			  }
		}catch(Exception e){}
		//����ǹ��������֣���Ҫ�ϴ�������
		if (music.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.add, ItemType.music, music.getFileName(), music.getMusicName(), music.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
	}
	
	//ɾ��һ������
	public static void deleteMusic(int i) {
		//����ǹ������֣���Ҫɾ��������������
		Music music = musicList.get(i);
		if (music.getAuthority() == Authority.isPublic) {
			TransMonitor newTrans = new TransMonitor(new Transaction(TransType.delete, ItemType.music, music.getFileName(), music.getMusicName(), music.getAuthority(), -1));
			newTrans.setName("�洢����");
			try {
				newTrans.start();
			}catch (Exception e) {}
		}
		//ɾ�����ظ���
		File toDel = new File(music.getFileName());
		if (toDel.isFile()) toDel.delete();
		//�ڴ�ͬ��
		musicList.remove(i);
	}
	
	//�����޸�Ȩ��
	public static void changeMusicAuthority(int i) {
		Music music = musicList.get(i);
		if (music.getAuthority() == Authority.isPrivate)
			music.setAnthority(Authority.isPublic);
		else
			music.setAnthority(Authority.isPrivate);
		TransMonitor newTrans = new TransMonitor(new Transaction(TransType.changeAuthority, ItemType.music, music.getFileName(), music.getMusicName(), music.getAuthority(), -1));
		newTrans.setName("�洢����");
		try {
			newTrans.start();
		}catch (Exception e) {}
	}
	
	//��ȡһ�������ļ���
	public static String newFileName(String ext) {
		return System.getProperty("user.dir")+"/content/music/" + String.valueOf(System.currentTimeMillis())+"."+ext;
	}
	
	//�������б�д�ش���
	public static void writeBack() {
		if (musicList != null){
			try {
				String path=System.getProperty("user.dir")+"/content/list_music";
				ObjectOutputStream rw =new ObjectOutputStream(new FileOutputStream(path));
				for (int i = 0; i < musicList.size(); ++i) {
					rw.writeObject(musicList.get(i));
				}
				rw.close();
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "�����б�����ʱ������������", "����", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	//��������
	@SuppressWarnings("static-access")
	public static void playMusic(int i) {
		if (musicPlayer == null) musicPlayer = new MusicPlayer();
		musicPlayer.path = musicList.get(i).getFileName();
		musicPlayer.musicIndex = i;
		musicPlayer.buildPlayer();
		//musicPlayer.setVisible(true);
		Thread viewerTrd = new Thread(musicPlayer);
		viewerTrd.start();
	}
	
	//������������
	public static void playWebMusic(String path, String name) {
		if (musicPlayer == null) musicPlayer = new MusicPlayer();
		musicPlayer.buildWebPlayer(path, name);
		//musicPlayer.setVisible(true);
		Thread viewerTrd = new Thread(musicPlayer);
		viewerTrd.start();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		addMusic();
		MainFrame.resetMainBoard();
	}
}
