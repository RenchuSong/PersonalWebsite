package trans;

import global.Authority;
import global.ItemType;
import global.TransType;
import global.Transaction;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;

@SuppressWarnings("unused")
class ClientServerTransactionMonitor {
	//�ͻ���-�����������б�
	public static Queue<ClientServerTransaction> transactionList = new LinkedList<ClientServerTransaction>();
}

/**
 * �ͻ�������������Ӳ��շ���Ϣ���߳���
 * @author Song Renchu
 *
 */
public class Client2Server extends Thread{	
	//�߳�����
	String name;
	
	//�Ƿ��������������
	public boolean connected = false;
	public boolean loggedOut = false;
	
	//Socket���
	Socket mysocket;
	DataInputStream in = null;
	DataOutputStream out = null;
	
	//���µĿͻ������������������
	public static ClientServerTransaction newTransaction;
	
	//ѹ��ǳ�
	public void logOut() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.logout, null);
		//work();
	}
	
	//ѹ���¼
	public void logIn() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.login, null);
		//work();
	}
	
	//����Ԫ������
	public void localTransaction(Transaction transaction) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.localTransaction, transaction);
		//work();
	}
	
	//�����û�
	public void createUser() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.createUser, null);
		//work();
	}
	
	//��ȡ��������IP��ַ
	private String getServerIP() {
		try {
			BufferedReader fin = new BufferedReader(new FileReader(System.getProperty("user.dir")+"/config/server_address"));
			return fin.readLine();
		}catch (Exception e) {
			//System.out.println("��ȡ��������ַʧ��");
		}
		return null;
	}
	
	//���Ӻ���
	public void addFriend(int userId) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.addfriend,null);
		newTransaction.intData1 = userId;
	}
	
	//��ѯӦ��
	public void searchApp(String appName) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.searchApp,null);
		newTransaction.strData1 = appName;
	}
	//����Ӧ��
	public void downloadApp(String appName) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.downloadApp,null);
		newTransaction.strData1 = appName;
	}
	
	
	//��ѯ�û�
	public void searchUser(String userName) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.searchUser,null);
		newTransaction.strData1 = userName;
	}
	
	//��ȷ�Ϻ����б�
	public void needConfirmFriendList() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.needConfirmFriendList,null);
	}
	
	//�����б�
	public void friendList() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.friendList, null);
	}
	
	//�����б�
	public void messageList() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.messageList, null);
	}
	//��������
	public void addMessage(int userId, String content) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.addMessage, null);
		newTransaction.intData1 = userId;
		newTransaction.strData1 = content;
	}
	//������
	public void newsList() {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.freshNews, null);
	}
	//�鿴��Դ
	public void viewResource(int orderId, int fromId, String itemType, String fileName) {
		newTransaction = new ClientServerTransaction(ClientServerTransactionType.viewResource, null);
		newTransaction.intData1 = orderId;
		newTransaction.intData2 = fromId;
		newTransaction.strData1 = itemType;
		newTransaction.strData2 = fileName;
	}
	
	//ͬ���ڷ���������
	private synchronized void work() {
		if (name.equals("�洢����")) {
			//�洢�����򽫹���ʱ�����������д���б�
			if (newTransaction!=null) {
				//����ǵǳ�����ô��ǰ�����������ȫ��д�أ�Ȼ���͵ǳ�����
				if (newTransaction.transType==ClientServerTransactionType.logout) {
					//������δ��ɵ�����д�������б�
					while (!ClientServerTransactionMonitor.transactionList.isEmpty()) {
						ClientServerTransaction theTransaction = ClientServerTransactionMonitor.transactionList.poll();
						if (theTransaction != null) {
							if (theTransaction.transType == ClientServerTransactionType.localTransaction) {
								TransMonitor newTrans = new TransMonitor(theTransaction.localTransaction);
								newTrans.setName("�洢����");
								try {
									newTrans.start();
								}catch (Exception e) {}
							}
						}
					}
				}
				
				ClientServerTransactionMonitor.transactionList.offer(newTransaction);
			}
		}else if(name.equals("��������")){
			while (true) {
				try {
					//��һ�ν������ӣ���ȡ��ַ
					String serverIP = getServerIP();
					if (serverIP == null) return;
					mysocket = new Socket(serverIP, 32768);
					in = new DataInputStream(mysocket.getInputStream());
					out = new DataOutputStream(mysocket.getOutputStream());
					out.writeUTF("LogIn");
					//��ȡ�˿ڵ�ַ
					int port = in.readInt();
					mysocket = new Socket(serverIP, port);
					in = new DataInputStream(mysocket.getInputStream());
					out = new DataOutputStream(mysocket.getOutputStream());
					//�������ӳɹ�
					this.connected = true;
					/*for (int i = 0; i< 50;++i){
						out.writeUTF("ylq");
						String res = in.readUTF();
						Thread.sleep(500);
					}
					out.writeUTF("LogOut");
					return;*/
					
					//��ʼ��������
					while (true) {
						
						try {
							newTransaction = ClientServerTransactionMonitor.transactionList.poll();
							//����ǵǳ�����ִ�еǳ��߼�
							if (newTransaction !=null) {
								//�ǳ��߼�
								if (newTransaction.transType == ClientServerTransactionType.logout) {
									out.writeUTF("LogOut");
									@SuppressWarnings("unused")
									String request = in.readUTF();
									loggedOut = true;
									return;
								}else
								//ע������
								if (newTransaction.transType == ClientServerTransactionType.createUser) {
									out.writeUTF("CreateUser");
									out.writeUTF(Account.user.getName());
									out.writeBoolean(Account.user.isGirl());
									out.writeUTF(Account.user.getIntroduction());
									int newUserId = in.readInt();
									try {
										File file = new File(System.getProperty("user.dir")+"/userdata/userPhoto.png");
										out.writeLong(file.length());
										//System.out.println(file.length());
										DataInputStream fis = new DataInputStream(new BufferedInputStream(new FileInputStream(System.getProperty("user.dir")+"/userdata/userPhoto.png")));
										////System.out.println(System.getProperty("user.dir")+"/userdata/userPhoto.png");
										int bufSize = 8192;
										byte[] buf = new byte[bufSize];
										while (true) {
											int read = 0;
											if (fis!=null) {
												read = fis.read(buf);
											}
											//System.out.println(read);
											if (read == -1) break;
											out.write(buf, 0, read);
										}
										out.flush();
										fis.close();
									}catch(Exception e) {
										//System.out.println("�ͻ��������������ͷ�����"+e);
									}
									Account.user.setId(newUserId);
								}else
								//���û�Id���û�ͷ��
								if (newTransaction.transType == ClientServerTransactionType.login) {
									out.writeUTF("UserId");
									out.writeInt(Account.user.getId());
									try {
										File file = new File(System.getProperty("user.dir")+"/userdata/userPhoto.png");
										out.writeLong(file.length());
										//System.out.println(file.length());
										DataInputStream fis = new DataInputStream(new BufferedInputStream(new FileInputStream(System.getProperty("user.dir")+"/userdata/userPhoto.png")));
										////System.out.println(System.getProperty("user.dir")+"/userdata/userPhoto.png");
										int bufSize = 8192;
										byte[] buf = new byte[bufSize];
										while (true) {
											int read = 0;
											if (fis!=null) {
												read = fis.read(buf);
											}
											//System.out.println(read);
											if (read == -1) break;
											out.write(buf, 0, read);
										}
										out.flush();
										fis.close();
									}catch(Exception e) {
										//System.out.println("�ͻ��������������ͷ�����"+e);
									}
									@SuppressWarnings("unused")
									boolean done = in.readBoolean();
								}else
								//��������
								if (newTransaction.transType == ClientServerTransactionType.localTransaction) {
									//System.out.println("Local");
									//����Ϊ����Ԫ������
									out.writeUTF("LocalItem");
									Transaction trans = newTransaction.localTransaction;
									//��������
									if (trans.transType == TransType.add) 
										out.writeUTF("add");
									else if (trans.transType == TransType.delete) 
										out.writeUTF("delete");
									else if (trans.transType == TransType.download) 
										out.writeUTF("download");
									else if (trans.transType == TransType.modify) 
										out.writeUTF("modify");
									else if (trans.transType == TransType.changeAuthority) 
										out.writeUTF("changeAuthority");
									//Ԫ������
									if (trans.itemType == ItemType.article)
										out.writeUTF("article");else
									if (trans.itemType == ItemType.photo)
										out.writeUTF("photo");else
									if (trans.itemType == ItemType.music)
										out.writeUTF("music");else
									if (trans.itemType == ItemType.video)
										out.writeUTF("video");else
									if (trans.itemType == ItemType.app)
										out.writeUTF("app");
									//Ԫ������
									out.writeUTF(trans.itemName);
									//Ԫ������
									out.writeUTF(trans.itemDescription);
									//�޸�Ȩ����Ҫд��Ȩ��
									if (trans.transType == TransType.changeAuthority) {
										//˽�У�False
										if (trans.newAuthority == Authority.isPrivate)
											out.writeBoolean(false);
										else //���У�True
											out.writeBoolean(true);
									}
									//���أ�д���������û���Id
									if (trans.transType == TransType.download)
										out.writeInt(trans.fromId);
									//���ӻ��޸Ļ򹫿���д�ļ�
									if (trans.transType == TransType.add || trans.transType == TransType.modify || (trans.transType == TransType.changeAuthority && trans.newAuthority == Authority.isPublic)){
										try {
											File file = new File(trans.itemName);
											out.writeLong(file.length());
											DataInputStream fis = new DataInputStream(new BufferedInputStream(new FileInputStream(trans.itemName)));
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (true) {
												int read = 0;
												if (fis!=null) {
													read = fis.read(buf);
												}
												if (read == -1) break;
												out.write(buf, 0, read);
											}
											out.flush();
											fis.close();
										}catch(Exception e) {
											//System.out.println("�ͻ���������������ļ�����"+e);
										}
									}
									//ת���ļ��������Ķ���ɱ��
									if (trans.transType == TransType.download) {
										//�����ļ�
										/**
										 * Need For Complete
										 */
										/*long length = in.readLong();
										try {
											DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/server/"+userId+"/userPhoto.png")));
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (length > 0) {
												int read = 0;
													if (in!=null) {
													read = in.read(buf);
												}
												if (read == -1) break;
												fos.write(buf, 0, read);
												length -= read;
											}
											fos.flush();
											fos.close();
										}catch(Exception e) {
											//System.out.println("����������ͷ�����"+e);
										}*/
									}else {
										in.readUTF();
									}
								}else
								//���Ӻ���
								if (newTransaction.transType == ClientServerTransactionType.addfriend) {
									out.writeUTF("AddFriend");
									out.writeInt(newTransaction.intData1);
									@SuppressWarnings("unused")
									boolean done = in.readBoolean();
									//System.out.println("���Ӻ��ѣ�"+done);
								}else
								//�����û��������б�����ȷ���б�
								if (newTransaction.transType == ClientServerTransactionType.searchUser ||
									newTransaction.transType == ClientServerTransactionType.friendList ||
									newTransaction.transType == ClientServerTransactionType.needConfirmFriendList ) {
									//д��ͬ����
									if (newTransaction.transType == ClientServerTransactionType.searchUser) {
										out.writeUTF("SearchUser");
										out.writeUTF(newTransaction.strData1);
									}
									if (newTransaction.transType == ClientServerTransactionType.friendList)
										out.writeUTF("FriendList");
									if (newTransaction.transType == ClientServerTransactionType.needConfirmFriendList)
										out.writeUTF("NeedConfirmFriendList");
									
									out.flush();
									//System.out.println("here");
									
									FriendMonitor.intResult1.clear();
									FriendMonitor.strResult1.clear();
									FriendMonitor.boolResult1.clear();
									FriendMonitor.strResult2.clear();
									//System.out.println("here2");
									
									//���������û�����������int1��
									int userNumber = in.readInt();
									FriendMonitor.int1 = userNumber;
									//System.out.println("here3");
									
									for (int i=0;i<userNumber;++i) {
										//System.out.println("here"+i);
										
										//�����û�Id
										FriendMonitor.intResult1.add(in.readInt());
										//�����û���
										FriendMonitor.strResult1.add(in.readUTF());
										//�����û��Ա�
										FriendMonitor.boolResult1.add(in.readBoolean());
										//�����û����
										FriendMonitor.strResult2.add(in.readUTF());
										//�����û�ͷ���ļ�
										long length = in.readLong(); //�ļ�����
										//System.out.println("here--"+i);
										try {
											DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+i+".png")));
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (length > 0) {
												int read = 0;
												if (length < bufSize) {
													if (in!=null) {
														read = in.read(buf, 0, (int) length);
													}
												}else
												if (in!=null) {
													read = in.read(buf);
												}
												if (read == -1) break;
												fos.write(buf, 0, read);
												length -= read;
												//System.out.println(length);
											}
											fos.flush();
											fos.close();
										}catch(Exception e) {
											//System.out.println("�ͻ��˽���ͷ�����"+e);
										}
										//System.out.println("here-end"+i);
									}
									//���ι�������
									while (FriendMonitor.isWorking ){
										FriendMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}else
								//�����б�
								if (newTransaction.transType == ClientServerTransactionType.messageList) {
									out.writeUTF("MessageList");
									out.flush();
									//��������
									MessageMonitor.int1 = in.readInt();
									//System.out.println(MessageMonitor.int1);
									MessageMonitor.intResult1.clear();
									MessageMonitor.strResult1.clear();
									MessageMonitor.intResult2.clear();
									MessageMonitor.strResult2.clear();
									//System.out.println(1);
									for (int i = 0; i<MessageMonitor.int1;++i) {
										//�����û�Id
										MessageMonitor.intResult1.add(in.readInt());
										//System.out.println(2);
										//�����û�Name
										MessageMonitor.strResult1.add(in.readUTF());
										//System.out.println(3);
										//�����û�ͷ���ļ�
										long length = in.readLong(); //�ļ�����
										//System.out.println(4);
										try {
											DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+i+".png")));
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (length > 0) {
												int read = 0;
												if (length < bufSize) {
													if (in!=null) {
														read = in.read(buf, 0, (int) length);
													}
												}else
												if (in!=null) {
													read = in.read(buf);
												}
												if (read == -1) break;
												fos.write(buf, 0, read);
												length -= read;
												//System.out.println(length);
											}
											fos.flush();
											fos.close();
										}catch(Exception e) {
											//System.out.println("�ͻ��˽���ͷ�����"+e);
										}
										//System.out.println(5);
										//����ʱ��
										MessageMonitor.intResult2.add(in.readInt());
										//System.out.println(6);
										//��������
										MessageMonitor.strResult2.add(in.readUTF());
										//System.out.println(7);
									}
									//���ι�������
									while (MessageMonitor.isWorking ){
										MessageMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}else
								//������
								if (newTransaction.transType == ClientServerTransactionType.addMessage) {
									out.writeUTF("AddMessage");
									out.writeInt(newTransaction.intData1);
									out.writeUTF(newTransaction.strData1);
									in.readBoolean();
								}else
								//����Ӧ��
								if (newTransaction.transType == ClientServerTransactionType.searchApp) {
									out.writeUTF("SearchApp");
									out.writeUTF(newTransaction.strData1);
									//Ӧ������
									AppMonitor.int1 = in.readInt();
									//System.out.println(AppMonitor.int1);
									AppMonitor.strResult1.clear();
									for (int i = 0; i < AppMonitor.int1; ++i) {
										//Ӧ����
										AppMonitor.strResult1.add(in.readUTF());
										//Ӧ��ͼƬ
										long length = in.readLong(); //�ļ�����
										//System.out.println("here--"+i);
										try {
											DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+i+".png")));
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (length > 0) {
												int read = 0;
												if (length < bufSize) {
													if (in!=null) {
														read = in.read(buf, 0, (int) length);
													}
												}else
												if (in!=null) {
													read = in.read(buf);
												}
												if (read == -1) break;
												fos.write(buf, 0, read);
												length -= read;
												//System.out.println(length);
											}
											fos.flush();
											fos.close();
										}catch(Exception e) {
											//System.out.println("�ͻ��˽���ͷ�����"+e);
										}
									}
									//���ι�������
									while (AppMonitor.isWorking ){
										AppMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}else
								//����Ӧ��
								if (newTransaction.transType == ClientServerTransactionType.downloadApp) {
									out.writeUTF("DownloadApp");
									out.writeUTF(newTransaction.strData1);
									//Ӧ��ͼƬ
									long length = in.readLong(); //�ļ�����
									try {
										DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/content/app/"+newTransaction.strData1+".png")));
										int bufSize = 8192;
										byte[] buf = new byte[bufSize];
										while (length > 0) {
											int read = 0;
											if (length < bufSize) {
												if (in!=null) {
													read = in.read(buf, 0, (int) length);
												}
											}else
											if (in!=null) {
												read = in.read(buf);
											}
											if (read == -1) break;
											fos.write(buf, 0, read);
											length -= read;
											//System.out.println(length);
										}
										fos.flush();
										fos.close();
									}catch(Exception e) {
										//System.out.println("�ͻ��˽���Ӧ��ͼƬ����"+e);
									}
									//Ӧ��
									length = in.readLong(); //�ļ�����
									try {
										DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/content/app/"+newTransaction.strData1+".jar")));
									
										int bufSize = 8192;
										byte[] buf = new byte[bufSize];
										while (length > 0) {
											int read = 0;
											if (length < bufSize) {
												if (in!=null) {
													read = in.read(buf, 0, (int) length);
												}
											}else
											if (in!=null) {
												read = in.read(buf);
											}
											if (read == -1) break;
											fos.write(buf, 0, read);
											length -= read;
											//System.out.println(length);
										}
										fos.flush();
										fos.close();
									}catch(Exception e) {
										//System.out.println("�ͻ��˽���Ӧ��ͼƬ����"+e);
									}
									
									//���ι�������
									while (AppMonitor.isWorking ){
										AppMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}else
								//������	
								if (newTransaction.transType == ClientServerTransactionType.freshNews) {
									out.writeUTF("NewsList");
									//����������
									System.out.println("FUck");
									NewsMonitor.int1 = in.readInt();
									System.out.println("FUck2");
									//System.out.println("----------"+NewsMonitor.int1+"----------");
									//Clear
									NewsMonitor.boolResult1.clear();
									NewsMonitor.boolResult2.clear();
									NewsMonitor.intResult1.clear();
									NewsMonitor.intResult2.clear();
									NewsMonitor.intResult3.clear();
									NewsMonitor.strResult1.clear();
									NewsMonitor.strResult2.clear();
									NewsMonitor.strResult3.clear();
									NewsMonitor.strResult4.clear();
									NewsMonitor.strResult5.clear();
									
									for (int i=0; i<NewsMonitor.int1; ++i) {
										System.out.println(i+" Fuck");
										//�Ƿ���ת�ص�
										boolean isTransfer = in.readBoolean();
										//System.out.println(isTransfer);
										NewsMonitor.boolResult1.add(isTransfer);
										
										//��ת�ص�
										if (isTransfer) {
											//ת���û�Id
											int transId = in.readInt();
											NewsMonitor.intResult1.add(transId);
											//System.out.println(transId);
											
											//ת���û���
											String userName = in.readUTF();
											NewsMonitor.strResult1.add(userName);
											//System.out.println(userName);
											
											NewsMonitor.boolResult2.add(false);
										}else {//�Ƿ�����
											NewsMonitor.intResult1.add(-1);
											NewsMonitor.strResult1.add(null);
											//�Ƿ��·�����
											NewsMonitor.boolResult2.add(in.readBoolean());
										}
										
										//ת�ػ��ϴ�ʱ��
										NewsMonitor.intResult2.add(in.readInt());
										//ԭʼ�û�Id
										NewsMonitor.intResult3.add(in.readInt());
										//ԭʼ�û���
										NewsMonitor.strResult2.add(in.readUTF());
										//�ļ����ͣ�����֮һ��
										String itemType = in.readUTF();
										NewsMonitor.strResult3.add(itemType);
										//�ļ���
										NewsMonitor.strResult4.add(in.readUTF());
										//�ļ�����
										NewsMonitor.strResult5.add(in.readUTF());
										//�û�ͷ��
										System.out.println(itemType);
										long length = in.readLong(); //�ļ�����
										try {
											DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+i+".png")));
										
											int bufSize = 8192;
											byte[] buf = new byte[bufSize];
											while (length > 0) {
												int read = 0;
												if (length < bufSize) {
													if (in!=null) {
														read = in.read(buf, 0, (int) length);
													}
												}else
												if (in!=null) {
													read = in.read(buf);
												}
												if (read == -1) break;
												fos.write(buf, 0, read);
												length -= read;
												//System.out.println(length);
											}
											fos.flush();
											fos.close();
										}catch(Exception e) {
											//System.out.println("�ͻ��˽���ͼƬ����"+e);
										}
										//�����ͼƬ������ʾͼƬ����ͼƬ������
										System.out.println(itemType);
										if (itemType.equals("photo")) {
											System.out.println("Fuck ");
											length = in.readLong(); //�ļ�����
											try {
												DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+i+"_photo.png")));
											
												int bufSize = 8192;
												byte[] buf = new byte[bufSize];
												while (length > 0) {
													int read = 0;
													if (length < bufSize) {
														if (in!=null) {
															read = in.read(buf, 0, (int) length);
														}
													}else
													if (in!=null) {
														read = in.read(buf);
													}
													if (read == -1) break;
													fos.write(buf, 0, read);
													length -= read;
													//System.out.println(length);
												}
												fos.flush();
												fos.close();
											}catch(Exception e) {
												//System.out.println("�ͻ��˽���ͼƬ����"+e);
											}
										}
										
									}
									
									//���ι�������
									while (NewsMonitor.isWorking ){
										NewsMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}else
								//�鿴������Դ
								if (newTransaction.transType == ClientServerTransactionType.viewResource) {
									System.out.println("here");
									
									//����
									out.writeUTF("ViewSRC");
									//��ʱ�ļ��ļ���
									String fileName = String.valueOf(newTransaction.intData1);
									fileName += newTransaction.strData2.substring(newTransaction.strData2.lastIndexOf("."),newTransaction.strData2.length());
									
									//��Դλ��
									out.writeInt(newTransaction.intData2);
									out.writeUTF(newTransaction.strData1);
									out.writeUTF(newTransaction.strData2);
									System.out.println("here");
									
									DownloadMonitor.strData1 = fileName;
									//�����ļ�
									long length = in.readLong(); //�ļ�����
									try {
										DataOutputStream fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.dir")+"/tmp/"+fileName)));
									
										int bufSize = 8192;
										byte[] buf = new byte[bufSize];
										while (length > 0) {
											int read = 0;
											if (length < bufSize) {
												if (in!=null) {
													read = in.read(buf, 0, (int) length);
												}
											}else
											if (in!=null) {
												read = in.read(buf);
											}
											if (read == -1) break;
											fos.write(buf, 0, read);
											length -= read;
											//System.out.println(length);
										}
										fos.flush();
										fos.close();
									}catch(Exception e) {
										//System.out.println("�ͻ��˽���ͼƬ����"+e);
									}
									
									//���ι�������
									while (DownloadMonitor.isWorking ){
										DownloadMonitor.isWorking = false;
										//try {Thread.sleep(100);}catch(Exception e){}
									}
								}
								//else
									
							}
							
						}catch (Exception e) {
							/**
							 * ������
							 */
							e.printStackTrace();
							
							//System.out.println("Client2Server ����������:"+e);
							//ClientServerTransactionMonitor.transactionList.offer(newTransaction);
							
							//�������ӶϿ�
							break;
						}
						
						try {
							sleep(1000);
						}catch (Exception e){}
					}
				}catch (Exception e) {
					//�������ӶϿ�
					this.connected = false;
					//�ر�Socket���������
					if (in!=null)
						try {
							in.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					if (out!=null)
						try {
							out.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					if (mysocket!=null) {
						try {
							mysocket.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					//System.out.println("Client �������ӶϿ�");
					//������ȫ����Ϊ������
					FriendMonitor.isWorking = false;
					MessageMonitor.isWorking = false;
					AppMonitor.isWorking = false;
					NewsMonitor.isWorking = false;
					DownloadMonitor.isWorking = false;
					
					ClientServerTransactionMonitor.transactionList.clear();
					//ѹ���˻���Ϣ
					if (Account.user.getId() == -1) {
						//δע������
						//����һ��ע������
						createUser();
						ClientServerTransactionMonitor.transactionList.offer(newTransaction);
					}else {
						//ע������
						logIn();
						ClientServerTransactionMonitor.transactionList.offer(newTransaction);
					}
					try {
						sleep(3000);
					}catch (Exception ex){}
				}
			}
		}
	}
	
	public void run() {
		name = this.getName();
		////System.out.println(name);
		work();
	}
}

/**
 * �ͻ��� - ������ ����
 * @author Song Renchu
 *
 */
class ClientServerTransaction {
	//��������
	public ClientServerTransactionType transType = null;
	//��������
	public Transaction localTransaction = null;
	//�����������ݶ�
	public int intData1,intData2;
	public String strData1,strData2;
	
	public ClientServerTransaction(ClientServerTransactionType transType, Transaction localTransaction) {
		this.transType = transType;
		if (this.transType == ClientServerTransactionType.localTransaction)
			this.localTransaction = localTransaction;
	}
}

//�ͻ��� - ������ ��������
enum ClientServerTransactionType {
	localTransaction, login, logout, createUser, addfriend, uploadskin, searchUser, friendList, needConfirmFriendList, messageList, addMessage, searchApp, downloadApp, freshNews, viewResource
}