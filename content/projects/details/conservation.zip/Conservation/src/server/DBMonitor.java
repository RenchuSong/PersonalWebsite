package server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBMonitor {
	
	Connection con;
	
	DBMonitor() {
		//����Jdbc-Odbc�Ž���
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		}catch (Exception e) {
			System.out.println("1"+e);
		}
	}
	
	//���ݴ������Ķ����½�һ���û�
	public int createUser(String userName, boolean isGirl, String userIntroduction) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//����
			sql.execute("INSERT INTO user(userName, userGender, userIntroduction) VALUES ('"+userName+"', "+isGirl+", '"+userIntroduction+"')");
			//��ȡ�û�Id
			ResultSet rs = sql.executeQuery("SELECT @@IDENTITY");
			if (rs.next()) {
				return rs.getInt(1);
			}
			con.close();
			return -1;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println(e);
			return -1;
		}
	}
	
	//���ݴ��������û�Id��ȡ�û���
	public String getUserName(int userId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT userName FROM user WHERE userId="+userId);
			String result = null;
			if (rs.next()) {
				result = rs.getString(1);
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return null;
		}
	}
	
	//���ݴ��������û�Id��ȡ�Ա�
	public boolean getUserGender(int userId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT userGender FROM user WHERE userId="+userId);
			boolean result = false;
			if (rs.next()) {
				result = rs.getBoolean(1);
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//���ݴ��������û�Id��ȡ�û����
	public String getUserIntroduction(int userId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT userIntroduction FROM user WHERE userId="+userId);
			String result = null;
			if (rs.next()) {
				result = rs.getString(1);
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return null;
		}
	}
	
	//�ϴ�һ����λ��Դ
	public boolean newItem(String itemType, int userId, String fileName, String fileDescription, int action) {
		int time = (int)(System.currentTimeMillis() / 1000);
		String userName = getUserName(userId);
		if (userName == null) return false;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//����
			sql.execute("INSERT INTO news(itemType, userName, userId, fileName, fileDescription, action, uploadTime) VALUES ('"+itemType+"', '"+userName+"',"+userId+", '"+fileName+"', '"+fileDescription+"' ,"+action+", "+time+")");
			con.close();
			return true;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//ɾ��һ����λ��Դ
	public boolean deleteItem(String itemType, int userId, String fileName) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//ɾ��
			sql.executeUpdate("DELETE FROM news WHERE itemType='"+itemType+"' and userId="+userId+" and fileName='"+fileName+"'");
			con.close();
			return true;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//����ת��������
	public boolean newTransfer(String itemType, String itemName, String itemDescription, int fromId, int userId) {
		String userName = getUserName(userId);
		String fromName = getUserName(fromId);
		int time = (int)(System.currentTimeMillis() / 1000);
		if (userName == null || fromName == null) return false;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//����
			sql.execute("INSERT INTO transfer(itemType, itemName, itemDescription, fromId,fromName, userId, userName, transferTime) VALUES ('"+itemType+"', '"+itemName+"', '"+itemDescription+"' , "+fromId+",'"+fromName+"',  "+userId+",'"+userName+"', "+time+")");
			con.close();
			return true;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//���Ӻ���
	public boolean newFriend(int user1, int user2) {
		if (user1 == user2) return false;
		String userName1 = getUserName(user1);
		String userName2 = getUserName(user2);
		if (userName1 == null || userName2 == null) return false;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			ResultSet rs = sql.executeQuery("SELECT userId1,userId2 FROM friend WHERE userId1="+user1+" and userId2="+user2);
			if (rs.next()) {
				con.close();
				return true;
			}
			rs = sql.executeQuery("SELECT userId1,userId2 FROM friend WHERE userId1="+user2+" and userId2="+user1);
			if (rs.next()) {
				//����
				sql.executeUpdate("UPDATE friend SET confirmed=true WHERE userId1="+user2+" and userId2="+user1);
			}else {
				//����
				sql.execute("INSERT INTO friend(userId1, userId2, confirmed) VALUES ("+user1+", "+user2+", false )");
			}
			con.close();
			return true;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//��ú����б�
	public ArrayList<Integer> friendList(int userId) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		String userName = getUserName(userId);
		if (userName == null) return result;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ѯһ������
			ResultSet rs = sql.executeQuery("SELECT userId2 FROM friend WHERE userId1="+userId+" AND confirmed=true");
			while (rs.next()) {
				result.add(new Integer(rs.getInt(1)));
			}
			//��һ������
			rs = sql.executeQuery("SELECT userId1 FROM friend WHERE userId2="+userId+" AND confirmed=true");
			while (rs.next()) {
				result.add(new Integer(rs.getInt(1)));
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return result;
		}
	}
	
	//��ȷ�ϵĺ���
	public ArrayList<Integer> needConfirmFriendList(int userId) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		String userName = getUserName(userId);
		if (userName == null) return result;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ѯ����
			ResultSet rs = sql.executeQuery("SELECT userId1 FROM friend WHERE userId2="+userId+" AND confirmed=false");
			while (rs.next()) {
				result.add(new Integer(rs.getInt(1)));
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return result;
		}
	}
	
	//����������ѯ�û�
	public ArrayList<Integer> searchUser(String userName) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ѯ����
			ResultSet rs = sql.executeQuery("SELECT userId FROM user WHERE userName LIKE '%"+userName+"%'");
			while (rs.next()) {
				result.add(new Integer(rs.getInt(1)));
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return result;
		}
	}	
	
	//��������
	public boolean newMessage(int userId1, int userId2, String content) {
		int time = (int)(System.currentTimeMillis() / 1000);
		String userName = getUserName(userId1);
		String userName2 = getUserName(userId2);
		
		if (userName == null || userName2 == null) return false;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//����
			sql.execute("INSERT INTO message(fromUserId, toUserId, context, submitTime) VALUES ("+userId1+", "+userId2+", '"+content+"', "+time+")");
			con.close();
			return true;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}
	
	//��ȡ�����û�Id
	public int messageFromId(int messageId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT fromUserId FROM message WHERE messageId="+messageId);
			if (rs.next()) {
				return rs.getInt(1);
			}
			con.close();
			return -1;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return -1;
		}
	}
	
	//��ȡ��������
	public String messageContent(int messageId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT context FROM message WHERE messageId="+messageId);
			if (rs.next()) {
				return rs.getString(1);
			}
			con.close();
			return null;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return null;
		}
	}
	//��ȡ����ʱ��
	public int messageTime(int messageId) {
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ȡ�û���
			ResultSet rs = sql.executeQuery("SELECT submitTime FROM message WHERE messageId="+messageId);
			if (rs.next()) {
				return rs.getInt(1);
			}
			con.close();
			return -1;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return -1;
		}
	}
	
	
	//�鿴�����б�
	public ArrayList<Integer> messageList(int userId) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//��ѯ����
			ResultSet rs = sql.executeQuery("SELECT messageId FROM message WHERE toUserId="+userId+" ORDER BY submitTime DESC");
			while (rs.next()) {
				result.add(new Integer(rs.getInt(1)));
			}
			con.close();
			return result;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return result;
		}
	}
	
	//��ȡ�ϴ��Լ�ת�ص�������
	public ArrayList<FreshNews> freshNewsList(int userId) {
		ArrayList<FreshNews> newsList = new ArrayList<FreshNews>();
		String userName = getUserName(userId);
		//��ȡ���˺����б�
		ArrayList<Integer> fList = friendList(userId);
		System.out.println(fList.size());
		
		String userCondition = "userId="+userId;
		if (fList.size()>0){
			//�����û���ѯ����
			//userCondition = "userId="+fList.get(0).intValue();
			for (int i=0;i<fList.size();++i)
				userCondition += " OR userId="+fList.get(i).intValue();
		}
		
		ArrayList<FreshNews> list1 = new ArrayList<FreshNews>();
		ArrayList<FreshNews> list2 = new ArrayList<FreshNews>();
		if (userName == null) return newsList;
		try {
			//��������
			con = DriverManager.getConnection("jdbc:odbc:sample","stu1","ok");
			Statement sql = con.createStatement();
			//�����ϴ�������
			ResultSet rs = sql.executeQuery("SELECT newsId,itemType,userId,userName,fileName,fileDescription,action,uploadTime FROM news WHERE "+userCondition+" ORDER BY uploadTime DESC");
			while (rs.next()) {
				FreshNews news = new FreshNews();
				news.isTransfer = false;
				
				news.newsId = rs.getInt(1);
				news.itemType = rs.getString(2);
				news.userId = rs.getInt(3);
				news.userName = rs.getString(4);
				news.fileName = rs.getString(5);
				news.content = rs.getString(6);
				news.isNew = (rs.getBoolean(7) == true?true:false);
				news.newsTime = rs.getInt(8);
				
				list1.add(news);
			}
			System.out.println(list1.size()+"ddd");
			//ת��������
			rs = sql.executeQuery("SELECT transferId,itemType,itemName,itemDescription,fromId,fromName,userId,userName,transferTime FROM transfer WHERE "+userCondition+" ORDER BY transferTime DESC");
			while (rs.next()) {
				
				FreshNews news = new FreshNews();
				news.isTransfer = true;
				
				news.newsId = rs.getInt(1);
				news.itemType = rs.getString(2);
				news.fileName = rs.getString(3);
				news.content = rs.getString(4);
				news.oriUserId = rs.getInt(5);
				news.oriUserName = rs.getString(6);
				news.userId = rs.getInt(7);
				news.userName = rs.getString(8);
				news.newsTime = rs.getInt(9);
				
				list2.add(news);
			}
			
			for (int i=0;i<list2.size();++i) {
				FreshNews news = list2.get(i);
				ResultSet rs2 = sql.executeQuery("SELECT newsId FROM news WHERE itemType='"+news.itemType+"' AND userId="+news.oriUserId+" AND fileName='"+news.fileName+"'");
				if (!rs2.next())
					list2.remove(i);
			}
			System.out.println(list2.size()+"sss");
			con.close();
			
			int p1 = 0, p2 = 0;
			while (p1 < list1.size() || p2 < list2.size()) {
				if (p1 < list1.size()) {
					if (p2 == list2.size() || list1.get(p1).newsTime >= list2.get(p2).newsTime){
						newsList.add(list1.get(p1));
						++p1;
						continue;
					}
				}
				if (p2<list2.size()) {
					if (p1 == list1.size() || list1.get(p1).newsTime <= list2.get(p2).newsTime){
						newsList.add(list2.get(p2));
						++p2;
					}
				}
			}
			
			return newsList;
		}catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return newsList;
		}
		//l
	}
	
	public static void main(String[] args) {
		DBMonitor dbm = new DBMonitor();
		//dbm.newMessage(14, 22, "U hate Me?");
		/*
		ArrayList<Integer> messageList = dbm.messageList(22);
		for (Integer i:messageList) {
			System.out.println(i.intValue());
			System.out.println(dbm.messageFromId(i.intValue()));
			System.out.println(dbm.messageContent(i.intValue()));
		}
		*/
		//System.out.println(dbm.createUser("wzl", false, "greedy"));
		//System.out.println(dbm.createUser("wzl", false, "greedy"));
		/*dbm.newFriend(18, 22);
		dbm.newFriend(19, 22);
		dbm.newFriend(22, 18);*/
		//dbm.newFriend(22, 19);
		
		//dbm.newFriend(22, 17);
		//dbm.newFriend(21, 22);
		
		//ArrayList<Integer> a = dbm.needConfirmFriendList(21);
		//for (Integer i:a)
		//System.out.println(i.intValue());
		//System.out.println(dbm.getUserGender(19));
		ArrayList<FreshNews> news = dbm.freshNewsList(22);
		System.out.println(news.size());
		for (int i=0;i<news.size();++i)
			news.get(i).print();
	}
}
