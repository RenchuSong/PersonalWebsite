package ui;

import global.Authority;
import global.Photo;
import global.SkinParameter;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import trans.ConservationFactory;
import trans.PhotoMonitor;
import trans.VideoMonitor;

//��Ƭ�ϴ���
@SuppressWarnings({ "serial", "unused" })
public class PhotoUploader extends JFrame{
	private JPanel close;
	private JTextField filePath;
	private JTextArea photoName;
	private JButton selBtn,upload, cancel;
	private JCheckBox share;
	JFileChooser fileChooser;
	
	public PhotoUploader() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/photo.png");
		this.setIconImage(im);
		this.setSize(500,250);
		this.setTitle("Conservation - ��Ƭ�鿴��");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"photo_uploader.png"), false);
		
		
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(463, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		
		JLabel title = new JLabel("��Ƭ�ϴ�");
		title.setBounds(20, 20, 200, 20);
		title.setFont(new Font(null, Font.BOLD, 20));
		title.setForeground(SkinParameter.photoUploaderTitle);
		this.add(title);
		JLabel selFile = new JLabel("ѡ���ļ�");
		selFile.setBounds(20, 62, 80, 14);
		selFile.setFont(new Font(null, Font.PLAIN, 14));
		selFile.setForeground(SkinParameter.photoUploaderContent);
		this.add(selFile);
		
		filePath = new JTextField();
		filePath.setBounds(90, 60, 200, 20);
		this.add(filePath);
		
		fileChooser = new JFileChooser(ConservationFactory.nowDirect);
		FileNameExtensionFilter ext = new FileNameExtensionFilter("GIFͼƬ (*.gif)","gif");
		fileChooser.setFileFilter(ext);
		ext = new FileNameExtensionFilter("PNGͼƬ (*.png)","png");
		fileChooser.setFileFilter(ext);
		ext = new FileNameExtensionFilter("JPGͼƬ (*.jpg)","jpg");
		fileChooser.setFileFilter(ext);
		
		selBtn = new JButton("ѡ����Ƭ");
		selBtn.setBackground(new Color(26, 105, 173));
		selBtn.setForeground(Color.white);
		selBtn.setBounds(300,60,90,20);
		selBtn.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					seletePhoto();
				}
			}
		);
		this.add(selBtn);
		
		JLabel photoDescription = new JLabel("��Ƭ����");
		photoDescription.setBounds(20, 102, 80, 14);
		photoDescription.setFont(new Font(null, Font.PLAIN, 14));
		photoDescription.setForeground(SkinParameter.photoUploaderContent);
		this.add(photoDescription);
		
		photoName = new JTextArea();
		photoName.setBounds(90, 100, 300, 80);
		photoName.setLineWrap(true);
		this.add(photoName);
		
		upload = new JButton("�ϴ�");
		upload.setBackground(new Color(26, 105, 173));
		upload.setForeground(Color.white);
		upload.setBounds(90,200,60,20);
		
		cancel = new JButton("���");
		cancel.setBackground(new Color(26, 105, 173));
		cancel.setForeground(Color.white);
		cancel.setBounds(180,200,60,20);
		cancel.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			}
		);
		upload.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					uploadPhoto();
				}
			}
		);
		//===============
		
		//===============
		this.add(upload);this.add(cancel);
		
		this.setVisible(true);
	}
	/*
	public static void main(String[] args) {
		new PhotoUploader();
	}
	*/
	public void uploadPhoto() {
		try {
			String photoName = this.filePath.getText().trim();
			String exp = "";
			if (photoName.endsWith(".jpg") || photoName.endsWith(".JPG")) exp = "jpg";else
			if (photoName.endsWith(".png") || photoName.endsWith(".PNG")) exp = "png";else
			if (photoName.endsWith(".gif") || photoName.endsWith(".GIF")) exp = "gif";else{
				JOptionPane.showMessageDialog(this, "ͼƬ�ļ���ʽ����", "����", JOptionPane.ERROR_MESSAGE);
				return;
			}
			photoName = this.photoName.getText().trim();
			Photo photo = new Photo(photoName, PhotoMonitor.newFileName(exp) , Authority.isPrivate);
			//�ĳ�һ���߳�
			PhotoMonitor oneMonitor = new PhotoMonitor();
			oneMonitor.photo = photo;
			oneMonitor.fromPath =  this.filePath.getText().trim();
			Thread trdPhoto = new Thread(oneMonitor);
			trdPhoto.start();
			this.photoName.setText(null);
			this.filePath.setText(null);
		}catch (Exception e) {;
			JOptionPane.showMessageDialog(this, "ͼƬ�ļ��ϴ�ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE);
		} 
	}
	
	public void seletePhoto() {
		int option = fileChooser.showOpenDialog(this);
		if(option == JFileChooser.APPROVE_OPTION) {
			try {
				String photoName = fileChooser.getSelectedFile().getName();
				ConservationFactory.nowDirect = (fileChooser.getSelectedFile().getParentFile()).toString();
				//System.out.println(videoName);
				String exp = "";
				if (photoName.endsWith(".jpg") || photoName.endsWith(".JPG")) exp = "jpg";else
				if (photoName.endsWith(".png") || photoName.endsWith(".PNG")) exp = "png";else
				if (photoName.endsWith(".gif") || photoName.endsWith(".GIF")) exp = "gif";else{
					JOptionPane.showMessageDialog(this, "ͼƬ�ļ���ʽ����", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				this.photoName.setText(photoName);
				filePath.setText(fileChooser.getSelectedFile().toString());
			}catch (Exception e) {
			} 
		}
	}
}
