package ui;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * ����ʵ������¼�����ͣ������������仯�İ�ť������ͼƬ��������
 * @author Song Renchu
 *
 */
@SuppressWarnings("serial")
public class UIPanel extends JPanel{

	int width,height;
	String bgName;
	
	public UIPanel(int width, int height, String bgName) {
		super();
		this.setBounds(0, 0, width, height);
		this.width = width;
		this.height = height;
		this.bgName = bgName;
	}
	
	public void bindMouseListener(final UIPanel uiPanel) {
		/*Graphics g = uiPanel.getGraphics();
		System.out.println(g);
		URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + uiPanel.bgName);
        ImageIcon img = new ImageIcon(url);
        g.drawImage(img.getImage(),0,0,uiPanel);
        */
		uiPanel.addMouseListener(new MouseListener(){    	
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = uiPanel.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + uiPanel.bgName);
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+uiPanel.bgName);
		        g.drawImage(img.getImage(),-uiPanel.width,0,uiPanel);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = uiPanel.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + uiPanel.bgName);
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+uiPanel.bgName);
		        g.drawImage(img.getImage(),0,0,uiPanel);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = uiPanel.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + uiPanel.bgName);
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+uiPanel.bgName);
		        g.drawImage(img.getImage(),-uiPanel.width*2,0,uiPanel);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = uiPanel.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + uiPanel.bgName);
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+uiPanel.bgName);
		        g.drawImage(img.getImage(),-uiPanel.width,0,uiPanel);
			}
		});
	}
}
