package ui;

import global.Article;
import global.Authority;
import global.Music;
import global.NowPage;
import global.Photo;
import global.SkinParameter;
import global.Video;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;
import javax.swing.ScrollPaneConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

import trans.ArticleMonitor;
import trans.ConservationFactory;
import trans.DownloadMonitor;
import trans.FriendMonitor;
import trans.MessageMonitor;
import trans.MusicMonitor;
import trans.NewsMonitor;
import trans.PhotoMonitor;
import trans.VideoMonitor;

@SuppressWarnings({ "unused", "serial" })
public class MainFrame extends JFrame{
	//���Ԫ��
	private UIPanel freshNews,article,photo,music,video,friend,message,app;
	private JPanel close, menuBar;
	private static JPanel mainBoard;
	private JLabel nowItem, nowItemTitle;
	private static JScrollPane mainScene;
	private static JPanel mainSceneInner;
	private static JLabel userPhoto;
	private static JPanel frame;
	private int changePhotoTime = 0;
	
	//����ҳ��Ԫ��
	private UIPanel addItem,updateList;
	private PhotoUploader photoUploader;
	private AddFriend addFriend;
	private DownloadApp downloadApp;
	
	public MainFrame() {
		init();
		UIUniversal.ToCenter(this);
	}
	
	private void refreshUI() {
		this.validate();
		this.repaint();
	}
	
	//�ϴ��µ��û�ͷ��
	private void uploadPhoto() {
		JFileChooser fileChooser = new JFileChooser(ConservationFactory.nowDirect);
		FileNameExtensionFilter ext = new FileNameExtensionFilter("GIFͼƬ (*.gif)","gif");
		fileChooser.setFileFilter(ext);
		ext = new FileNameExtensionFilter("PNGͼƬ (*.png)","png");
		fileChooser.setFileFilter(ext);
		ext = new FileNameExtensionFilter("JPGͼƬ (*.jpg)","jpg");
		fileChooser.setFileFilter(ext);
		++this.changePhotoTime;
		String t = String.valueOf(changePhotoTime);
		int option = fileChooser.showOpenDialog(this);
		if(option == JFileChooser.APPROVE_OPTION) {
			FileOutputStream out = null;
			String fromPath = fileChooser.getSelectedFile().getAbsolutePath();
			try {
				//�ο�http://blog.csdn.net/ta8210/article/details/2073817
				  int length=20000000;
				  FileInputStream in=new FileInputStream(new File(fromPath));
				  ProgressMonitorInputStream inputProgress = new ProgressMonitorInputStream(null, "���ڿ�����Ƭ�ļ�", in);
				  ProgressMonitor p = inputProgress.getProgressMonitor();
				  out=new FileOutputStream(new File(System.getProperty("user.dir")+"/userdata/userPhoto.png"));
				  
				  byte[] buffer=new byte[length];
				  while(true){
				   int ins=inputProgress.read(buffer);
				   if(ins==-1){
				    in.close();
				    out.flush();
				    out.close();
				    break;
				   }else
				    out.write(buffer,0,ins);
				  }
				  
			}catch(Exception e){}
			finally {
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		ConservationFactory.reloadMain();
		this.dispose();
	}
	//ˢ���û�ͷ��
	private void resetUserImage(String t) {
		System.out.println("resetPhoto");
		//ͼƬ����
		////System.out.println(photo.getFileName());
		//if (frame !=null)
		//	menuBar.remove(frame);
		//menuBar.validate();
		//menuBar.revalidate();
		userPhoto = new JLabel();
		//width=170 height=120 
		int showWidth = 100, showHeight = 100;
		try {
			FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/userdata/userPhoto"+t+".png"));
			BufferedImage   sourceImg = ImageIO.read(src);
			showWidth = sourceImg.getWidth();
			showHeight = sourceImg.getHeight();
			src.close();
			if (showHeight > 100) {
				showWidth = 100*showWidth/showHeight;
				showHeight = 100;
			}
			if (showHeight < 100) {
				showWidth = 100*100/showHeight;
				showHeight = 100;
			}
			if (showWidth < 100) {
				showHeight = 100 * 100/showWidth;
				showWidth = 100;
			}
		}catch (Exception e) {	
		}
		userPhoto.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/userdata/userPhoto"+t+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
		
		System.out.println(System.getProperty("user.dir")+"/userdata/userPhoto"+t+".png");
		userPhoto.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					uploadPhoto();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		frame = new JPanel();
		frame.setLayout(null);
		frame.setBounds(25, 15, 100, 100);
		userPhoto.setBounds((100-showWidth)/2, (100-showHeight)/2, showWidth, showHeight);
		frame.add(userPhoto);
		menuBar.add(frame);
	}
	
	private void closeTheWindow() {
		this.dispose();
	}
	
	public void init() {
		this.setTitle("Conservation ��Դ�����罻ƽ̨");
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/Conservation.png");
		this.setIconImage(im);
		this.setSize(800,600);
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"mainFrame.png"), false);
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(763, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				ConservationFactory.writeBack();
				System.exit(0);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		
		this.add(close);

		
		//��ർ����
		menuBar = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"menuBar.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		menuBar.setBounds(0,0,150,600);
		menuBar.setLayout(null);
		nowItem = new JLabel(new ImageIcon(UIUniversal.getInstance().getSkinPath()+"nowItem.png"));
		nowItem.setBounds(5, 20, 140, 40);
		
		//�û�ͷ��
		resetUserImage("");
		
		//������ť
		UIPanel change_skin = new UIPanel(32, 32, "change_skin.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"change_skin.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		
		change_skin.bindMouseListener(change_skin);
		change_skin.addMouseListener(
				new MouseListener() {
					@SuppressWarnings("static-access")
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						if (UIUniversal.getInstance().skinPath.equals("default"))
							UIUniversal.getInstance().setSkinPath("����ĺ��");
						else
							UIUniversal.getInstance().setSkinPath("default");
						ConservationFactory.reloadMain();
						closeTheWindow();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
		
		change_skin.setBounds(20, 550, 32, 32);
		menuBar.add(change_skin);
		
		freshNews = new UIPanel(80, 30, "freshNews.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"freshNews.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		freshNews.setBounds(35,125,80,30);
		article = new UIPanel(80, 30, "article.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"article.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		article.setBounds(35,165,80,30);
		photo = new UIPanel(80, 30, "photo.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"photo.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		photo.setBounds(35,205,80,30);
		music = new UIPanel(80, 30, "music.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"music.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		music.setBounds(35,245,80,30);
		video = new UIPanel(80, 30, "video.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"video.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		video.setBounds(35,285,80,30);
		friend = new UIPanel(80, 30, "friend.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"friend.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		friend.setBounds(35,325,80,30);
		message = new UIPanel(80, 30, "message.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"message.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		message.setBounds(35,365,80,30);
		app = new UIPanel(80, 30, "app.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"app.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		app.setBounds(35,405,80,30);
		freshNews.bindMouseListener(freshNews);
		freshNews.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.freshNews;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(false);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		article.bindMouseListener(article);
		article.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.article;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		photo.bindMouseListener(photo);
		photo.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.photo;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		music.bindMouseListener(music);
		music.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.music;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		video.bindMouseListener(video);
		video.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.video;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		friend.bindMouseListener(friend);
		friend.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.friend;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		message.bindMouseListener(message);
		message.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.message;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(false);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		app.bindMouseListener(app);
		app.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					ConservationFactory.nowPage = NowPage.app;
					resetNowItemTitle();
					resetMainBoard();
					addItem.setVisible(true);
					//mainBoard.validate();
					refreshUI();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		menuBar.add(freshNews);
		menuBar.add(article);
		menuBar.add(photo);
		menuBar.add(music);
		menuBar.add(video);
		menuBar.add(friend);
		menuBar.add(message);
		menuBar.add(app);
		
		menuBar.add(nowItem);
		this.add(menuBar);
		//�м�����������
		mainBoard = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"mainBoard.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		mainBoard.setBounds(175, 50, 600, 525);
		mainBoard.setLayout(null);
		nowItemTitle = new JLabel();
		
		resetNowItemTitle();
		nowItemTitle.setBounds(250, 5, 200, 30);
		nowItemTitle.setFont(new Font("����",Font.PLAIN, 20));
		mainBoard.add(nowItemTitle);
		//���ӡ������Ӱ�ť
		addItem = new UIPanel(20, 20, "new.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"new.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		updateList = new UIPanel(20, 20, "update.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"update.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		addItem.setBounds(520,10,20,20);
		addItem.bindMouseListener(addItem);
		updateList.setBounds(550,10,20,20);
		updateList.bindMouseListener(updateList);
		
		addItem.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					addLocalItem();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		updateList.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					resetMainBoard();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		mainBoard.add(addItem);
		mainBoard.add(updateList);
		
		resetMainBoard();
		
		this.add(mainBoard);
	}
	
	//����������������
	public void resetNowItemTitle() {
		String[] itemNameList = new String[]{"ȫ����̬","�ҵ���־","�ҵ���Ƭ","�ҵ�����","�ҵ���Ƶ","�ҵĺ���","ȫ������","�ҵ�Ӧ��"};
		if (ConservationFactory.nowPage == NowPage.freshNews){
			nowItemTitle.setText(itemNameList[0]);
			nowItem.setLocation(5, 120);
		}
		if (ConservationFactory.nowPage == NowPage.article){
			nowItemTitle.setText(itemNameList[1]);
			nowItem.setLocation(5, 160);
		}
		if (ConservationFactory.nowPage == NowPage.photo){
			nowItemTitle.setText(itemNameList[2]);
			nowItem.setLocation(5, 200);
		}
		if (ConservationFactory.nowPage == NowPage.music){
			nowItemTitle.setText(itemNameList[3]);
			nowItem.setLocation(5, 240);
		}
		if (ConservationFactory.nowPage == NowPage.video){
			nowItemTitle.setText(itemNameList[4]);
			nowItem.setLocation(5, 280);
		}
		if (ConservationFactory.nowPage == NowPage.friend){
			nowItemTitle.setText(itemNameList[5]);
			nowItem.setLocation(5, 320);
		}
		if (ConservationFactory.nowPage == NowPage.message){
			nowItemTitle.setText(itemNameList[6]);
			nowItem.setLocation(5, 360);
		}
		if (ConservationFactory.nowPage == NowPage.app){
			nowItemTitle.setText(itemNameList[7]);
			nowItem.setLocation(5, 400);
		}
		nowItemTitle.setForeground(new Color(150,150,150));
	}
	//��������������������
	public static void resetMainBoard() {
		if (mainSceneInner!= null)
			mainScene.remove(mainSceneInner);
		if (mainScene!=null)
			mainBoard.remove(mainScene);
		
		
		mainSceneInner = new JPanel();
		mainSceneInner.setSize(580, 100);
		mainSceneInner.setLayout(null);
		
		//mainScene.setBorder(BorderFactory.createLineBorder(Color.white));
		mainSceneInner.setBorder(BorderFactory.createLineBorder(Color.white));
		
		Dimension d = new Dimension(580,100);
		mainSceneInner.setPreferredSize(d);
		if (ConservationFactory.nowPage == NowPage.freshNews){
			for (int i = 0; i< 20; ++i) {
				if (ConservationFactory.client2server.connected) break;
				try {
					Thread.sleep(105);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//δ����������ʾ�޷���ȡ
			if (ConservationFactory.client2server.connected == false) {
				mainSceneInner.removeAll();
				UIPanel disconnect = new UIPanel(600, 480, "disconnect.png"){
					public void paintComponent(Graphics g) {
						ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"disconnect.png");
				        g.drawImage(img.getImage(),0,0,null);
				    }
				};
				disconnect.setBounds(0, 0, 600, 480);
				mainSceneInner.add(disconnect);
				mainSceneInner.setSize(580, 450);
				d = new Dimension(580,450);
				mainSceneInner.setPreferredSize(d);
			}else {
				//��ȡ������
				NewsMonitor.newsList();
				int loop = 0;
				while (NewsMonitor.isWorking)
					try {
						Thread.sleep(100);
						////System.out.println("news");
						++loop; if (loop>50) return;
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				int height = setNewsPanel();
				//�ܵ�Panel�߶�����
				mainSceneInner.setSize(580, height);
				d = new Dimension(580,height);
				mainSceneInner.setPreferredSize(d);
			}
			//�����
		}
		if (ConservationFactory.nowPage == NowPage.article) {
			ArticleMonitor.initArticleList();
			ArticleMonitor.loadArticle();
			int height = setArticlePanel();
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
		}
		if (ConservationFactory.nowPage == NowPage.music) {
			MusicMonitor.initMusicList();
			int height = setMusicPanel();
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
		}
		if (ConservationFactory.nowPage == NowPage.video) {
			VideoMonitor.initVideoList();
			int height = setVideoPanel();
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
		}
		if (ConservationFactory.nowPage == NowPage.photo) {
			PhotoMonitor.initPhotoList();
			int height = setPhotoPanel();
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
		}
		//����
		if (ConservationFactory.nowPage == NowPage.friend) {
			if (ConservationFactory.client2server.connected == false) {
				mainSceneInner.removeAll();
				UIPanel disconnect = new UIPanel(600, 480, "disconnect.png"){
					public void paintComponent(Graphics g) {
						ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"disconnect.png");
				        g.drawImage(img.getImage(),0,0,null);
				    }
				};
				disconnect.setBounds(0, 0, 600, 480);
				mainSceneInner.add(disconnect);
				mainSceneInner.setSize(580, 450);
				d = new Dimension(580,450);
				mainSceneInner.setPreferredSize(d);
			}else {
			
			//�Ȼ�ȡ�����Ӻ���
			FriendMonitor.needConfirmFriendList();
			int loop = 0;
			while (FriendMonitor.isWorking)
				try {
					Thread.sleep(100);
					//System.out.println("s");
					++loop; if (loop>100) return;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			int height = setNeedListPanel();
			//�ٻ�ȡ���к���
			
			FriendMonitor.friendList();
			while (FriendMonitor.isWorking)
				try {
					Thread.sleep(100);
					//System.out.println("r");
					++loop; if (loop>100) return;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			height = setFriendListPanel(height);
			//�ܵ�Panel�߶�����
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
			}
		}
		//����
		if (ConservationFactory.nowPage == NowPage.message) {
			if (ConservationFactory.client2server.connected == false) {
				mainSceneInner.removeAll();
				UIPanel disconnect = new UIPanel(600, 480, "disconnect.png"){
					public void paintComponent(Graphics g) {
						ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"disconnect.png");
				        g.drawImage(img.getImage(),0,0,null);
				    }
				};
				disconnect.setBounds(0, 0, 600, 480);
				mainSceneInner.add(disconnect);
				mainSceneInner.setSize(580, 450);
				d = new Dimension(580,450);
				mainSceneInner.setPreferredSize(d);
			}else {
			
			//��ȡ����
			MessageMonitor.messageList();
			int loop = 0;
			while (MessageMonitor.isWorking)
				try {
					Thread.sleep(100);
					//System.out.println("message");
					++loop; if (loop>50) return;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			int height = setMessagePanel();
			//�ܵ�Panel�߶�����
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
			}
		}
		//Ӧ��
		if (ConservationFactory.nowPage == NowPage.app) {
			int height = setAppPanel();
			mainSceneInner.setSize(580, height);
			d = new Dimension(580,height);
			mainSceneInner.setPreferredSize(d);
		}
		//Add Page, Modify Here
		
		mainScene = new JScrollPane(mainSceneInner, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainScene.setBounds(10, 40, 580, 470);
		mainScene.setBorder(BorderFactory.createLineBorder(Color.white));
		mainBoard.add(mainScene);
		mainBoard.validate();
	}
	//���ӣ����¡����֡���Ƶ��ͼƬ��Ӧ�á����ѣ�
	public void addLocalItem() {
		//������־
		if (ConservationFactory.nowPage == NowPage.article){
			new ArticleEditor(null, ArticleMonitor.newFileName());
		}
		
		//��������
		if (ConservationFactory.nowPage == NowPage.music){
			////System.out.println(ConservationFactory.nowDirect);
			JFileChooser fileChooser = new JFileChooser(ConservationFactory.nowDirect);
			FileNameExtensionFilter ext = new FileNameExtensionFilter("WAV�����ļ� (*.wav)","wav");
			fileChooser.setFileFilter(ext);
			ext = new FileNameExtensionFilter("MP3�����ļ� (*.mp3)","mp3");
			fileChooser.setFileFilter(ext);
			int option = fileChooser.showOpenDialog(this);
			if(option == JFileChooser.APPROVE_OPTION) {
				try {
					String musicName = fileChooser.getSelectedFile().getName();
					ConservationFactory.nowDirect = (fileChooser.getSelectedFile().getParentFile()).toString();
					////System.out.println(musicName);
					String exp = "";
					if (musicName.endsWith(".mp3") || musicName.endsWith(".MP3")) exp = "mp3";else
					if (musicName.endsWith(".wav") || musicName.endsWith(".WAV")) exp = "wav";else {
						JOptionPane.showMessageDialog(this, "�����ļ���ʽ����", "����", JOptionPane.ERROR_MESSAGE);
						return;
					}
					
					Music music = new Music(musicName, MusicMonitor.newFileName(exp) , Authority.isPrivate);
					//�ĳ�һ���߳�
					MusicMonitor oneMonitor = new MusicMonitor();
					oneMonitor.music = music;
					oneMonitor.fromPath =  fileChooser.getSelectedFile().getPath();
					Thread trdMusic = new Thread(oneMonitor);
					trdMusic.start();
					//MusicMonitor.addMusic(music, fileChooser.getSelectedFile().getPath());
					////System.out.println(fileChooser.getSelectedFile().getPath());
					//resetMainBoard();
					
					//
				}catch (Exception e) {
					JOptionPane.showMessageDialog(this, "�����ļ�����ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE);
				} 
			}
		}
		
		//������Ƶ
		if (ConservationFactory.nowPage == NowPage.video){
			////System.out.println(ConservationFactory.nowDirect);
			JFileChooser fileChooser = new JFileChooser(ConservationFactory.nowDirect);
			FileNameExtensionFilter ext = new FileNameExtensionFilter("MPG��Ƶ�ļ� (*.mpg)","mpg");
			fileChooser.setFileFilter(ext);
			ext = new FileNameExtensionFilter("AVI��Ƶ�ļ� (*.avi)","avi");
			fileChooser.setFileFilter(ext);
			int option = fileChooser.showOpenDialog(this);
			if(option == JFileChooser.APPROVE_OPTION) {
				try {
					String videoName = fileChooser.getSelectedFile().getName();
					ConservationFactory.nowDirect = (fileChooser.getSelectedFile().getParentFile()).toString();
					////System.out.println(videoName);
					String exp = "";
					if (videoName.endsWith(".mpg") || videoName.endsWith(".MPG")) exp = "mpg";else
					if (videoName.endsWith(".avi") || videoName.endsWith(".AVI")) exp = "avi";else {
						JOptionPane.showMessageDialog(this, "��Ƶ�ļ���ʽ����", "����", JOptionPane.ERROR_MESSAGE);
						return;
					}
					
					Video video = new Video(videoName, VideoMonitor.newFileName(exp) , Authority.isPrivate);
					//�ĳ�һ���߳�
					VideoMonitor oneMonitor = new VideoMonitor();
					oneMonitor.video = video;
					oneMonitor.fromPath =  fileChooser.getSelectedFile().getPath();
					Thread trdVideo = new Thread(oneMonitor);
					trdVideo.start();
				}catch (Exception e) {
					JOptionPane.showMessageDialog(this, "��Ƶ�ļ�����ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE);
				} 
			}
		
		}
		
		//������Ƭ
		if (ConservationFactory.nowPage == NowPage.photo){
			if (this.photoUploader == null) this.photoUploader = new PhotoUploader();
			photoUploader.setVisible(true);
		}
		
		//���Ӻ���
		if (ConservationFactory.nowPage == NowPage.friend){
			if (this.addFriend == null) this.addFriend = new AddFriend();
			addFriend.setVisible(true);
		}
		
		//����Ӧ��
		if (ConservationFactory.nowPage == NowPage.app) {
			if (this.downloadApp == null) this.downloadApp = new DownloadApp();
			downloadApp.setVisible(true);
			downloadApp.loadList();
		}
		//Add Page, Modify Here
		
	}
	//������־�б�
	public static int setArticlePanel() {
		int height = 0;
		ArticleMonitor.loadArticle();
		////System.out.println(ArticleMonitor.articleList.size());
		for (int i = ArticleMonitor.articleList.size()-1; i>=0; --i) {
			JPanel articlePane = new JPanel();
			articlePane.setBackground(Color.white);
			articlePane.setLayout(null);
			JLabel title = new JLabel(ArticleMonitor.articleItemList.get(i).title);
			title.setBounds(5,5,570,25);
			title.setFont(new Font(null, Font.BOLD, 16));
			title.setForeground(SkinParameter.itemTitle);
			articlePane.add(title);
			String mCont = ArticleMonitor.articleItemList.get(i).content;
			if (mCont.length() > 110) {
				mCont = mCont.substring(0, 98) + "����";
			}
			if (mCont.length() % 40 == 0 || mCont.length() % 40 > 30) {
				mCont = mCont.substring(0, 40*(mCont.length()/40) + (mCont.length() % 40 == 0?-10:30)) + "����";
			}
			mCont = "<html>" + mCont + "</html>";
			JLabel content = new JLabel(mCont);
			int contLen = ArticleMonitor.articleItemList.get(i).content.length() / 40 + 1;
			if (contLen > 3) contLen = 3;
			content.setBounds(5,30,570,contLen*20);
			content.setFont(new Font(null, Font.PLAIN, 14));
			articlePane.add(content);
			
			if (ArticleMonitor.articleItemList.get(i).authority == Authority.isPrivate) {
				JLabel isPrivate = new JLabel("����һƪ����˽����־");
				isPrivate.setFont(new Font(null,Font.ITALIC, 12));
				isPrivate.setForeground(SkinParameter.itemContent);
				isPrivate.setBounds(370, contLen*20 + 35, 130, 20);
				articlePane.add(isPrivate);
			}
			
			//��Ϊ���õı���
			final int p = i;
			
			//ɾ��һƪ����
			UIPanel delete = new UIPanel(18, 18, "delete.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"delete.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			delete.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						ArticleMonitor.deleteArticle(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			delete.setBounds(540, contLen*20 + 35, 18, 18);
			articlePane.add(delete);
			//�༭һƪ����
			UIPanel edit = new UIPanel(18, 18, "edit.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"edit.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			edit.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						new ArticleEditor(ArticleMonitor.articleItemList.get(p), ArticleMonitor.articleList.get(p));
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			edit.setBounds(510, contLen*20 + 35, 18, 18);
			articlePane.add(edit);
			articlePane.setBounds(0, height, 580, contLen*20 + 59);
			Dimension d = new Dimension(580,contLen*20 + 59);
			articlePane.setPreferredSize(d);
			
			articlePane.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						ArticleViewer viewer = new ArticleViewer(ArticleMonitor.articleItemList.get(p),ArticleMonitor.articleList.get(p), null);
						Thread viewerTrd = new Thread(viewer);
						viewerTrd.start();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			
			mainSceneInner.add(articlePane);
			height += contLen*20 + 60;
		}
		return height;
	}
	//���������б�
	public static int setMusicPanel() {
		int height = 0;
		//System.out.println(MusicMonitor.musicList.size());
		for (int i = MusicMonitor.musicList.size() -1; i >= 0; --i) {
			//ÿ�����ֵ����
			JPanel musicPane = new JPanel();
			musicPane.setLayout(null);
			musicPane.setBackground(Color.white);
			////System.out.println(MusicMonitor.musicList.get(i).getFileName());
			musicPane.setBounds(0, height, 580, 96);
			//����Logo
			Music music = MusicMonitor.musicList.get(i);
			final String exp;
			if (music.getFileName().endsWith(".mp3")) exp = "mp3";else exp = "wav";
			JPanel logo = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(System.getProperty("user.dir")+"/skin/global/"+exp+".png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			logo.setBounds(5, 10, 72, 72);
			musicPane.add(logo);
			//������
			JLabel musicName = new JLabel(music.getMusicName());
			musicName.setBounds(85, 10, 480, 20);
			musicName.setFont(new Font(null, Font.BOLD, 16));
			musicName.setForeground(SkinParameter.itemTitle);
			musicPane.add(musicName);
			//�ϴ�ʱ��
			long submitTime = Long.parseLong(music.getFileName().substring((System.getProperty("user.dir")+"/content/music/").length(), music.getFileName().length() - 4));
			JLabel musicSubmit = new JLabel("�ϴ��� "+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format(submitTime));
			musicSubmit.setBounds(85, 35, 200, 20);
			musicSubmit.setFont(new Font(null, Font.PLAIN, 12));
			musicSubmit.setForeground(SkinParameter.itemContent);
			musicPane.add(musicSubmit);
			
			//��Ϊ���õı���
			final int p = i;
			
			//ɾ��һ������
			UIPanel delete = new UIPanel(18, 18, "delete.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"delete.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			delete.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						MusicMonitor.deleteMusic(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			delete.setBounds(540, 64, 18, 18);
			musicPane.add(delete);
			
			//�ı����
			final String shs;
			if (music.getAuthority() == Authority.isPublic) shs = "cancel_share.png";
			else shs = "share.png";
			UIPanel share = new UIPanel(18, 18, shs){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+shs);
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			share.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						MusicMonitor.changeMusicAuthority(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			share.setBounds(510, 64, 18, 18);
			musicPane.add(share);
			
			//˽��������ʾ
			if (MusicMonitor.musicList.get(i).getAuthority() == Authority.isPrivate) {
				JLabel isPrivate = new JLabel("����һ������˽������");
				isPrivate.setFont(new Font(null,Font.ITALIC, 12));
				isPrivate.setForeground(SkinParameter.itemContent);
				isPrivate.setBounds(370, 64, 130, 20);
				musicPane.add(isPrivate);
			}
			
			//����/ֹͣ��ť
			final JPanel play = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"play.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			play.setBounds(85, 58, 24, 24);

			play.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						MusicMonitor.playMusic(p);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			
			musicPane.add(play);
			//���ӻ������
			mainSceneInner.add(musicPane);
			height += 97;
		}
		return height;
	}
	
	//������Ƶ�б�
	public static int setVideoPanel() {
		int height = 0;
		////System.out.println(VideoMonitor.videoList.size());
		for (int i = VideoMonitor.videoList.size() -1; i >= 0; --i) {
			//ÿ����Ƶ�����
			JPanel videoPane = new JPanel();
			videoPane.setLayout(null);
			videoPane.setBackground(Color.white);
			////System.out.println(VideoMonitor.videoList.get(i).getFileName());
			videoPane.setBounds(0, height, 580, 96);
			//��ƵLogo
			Video video = VideoMonitor.videoList.get(i);
			final String exp;
			if (video.getFileName().endsWith(".mpg")) exp = "mpg";else exp = "avi";
			JPanel logo = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(System.getProperty("user.dir")+"/skin/global/"+exp+".png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			logo.setBounds(5, 10, 72, 72);
			videoPane.add(logo);
			//��Ƶ��
			JLabel videoName = new JLabel(video.getVideoName());
			videoName.setBounds(85, 10, 480, 20);
			videoName.setFont(new Font(null, Font.BOLD, 16));
			videoName.setForeground(SkinParameter.itemTitle);
			videoPane.add(videoName);
			//�ϴ�ʱ��
			long submitTime = Long.parseLong(video.getFileName().substring((System.getProperty("user.dir")+"/content/video/").length(), video.getFileName().length() - 4));
			JLabel videoSubmit = new JLabel("�ϴ��� "+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format(submitTime));
			videoSubmit.setBounds(85, 35, 200, 20);
			videoSubmit.setFont(new Font(null, Font.PLAIN, 12));
			videoSubmit.setForeground(SkinParameter.itemContent);
			videoPane.add(videoSubmit);
			
			//��Ϊ���õı���
			final int p = i;
			
			//ɾ��һ����Ƶ
			UIPanel delete = new UIPanel(18, 18, "delete.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"delete.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			delete.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						VideoMonitor.deleteVideo(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			delete.setBounds(540, 64, 18, 18);
			videoPane.add(delete);
			
			//�ı����
			final String shs;
			if (video.getAuthority() == Authority.isPublic) shs = "cancel_share.png";
			else shs = "share.png";
			UIPanel share = new UIPanel(18, 18, shs){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+shs);
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			share.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						VideoMonitor.changeVideoAuthority(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			share.setBounds(510, 64, 18, 18);
			videoPane.add(share);
			
			//˽����Ƶ��ʾ
			if (VideoMonitor.videoList.get(i).getAuthority() == Authority.isPrivate) {
				JLabel isPrivate = new JLabel("����һ������˽����Ƶ");
				isPrivate.setFont(new Font(null,Font.ITALIC, 12));
				isPrivate.setForeground(SkinParameter.itemContent);
				isPrivate.setBounds(370, 64, 130, 20);
				videoPane.add(isPrivate);
			}
			
			//����/ֹͣ��ť
			final JPanel play = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"play.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			play.setBounds(85, 58, 24, 24);

			play.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						VideoMonitor.playVideo(p);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			
			videoPane.add(play);
			//���ӻ������
			mainSceneInner.add(videoPane);
			height += 97;
		}
		return height;
	}
	
	//��ʾ��Ƭ�б�
	public static int setPhotoPanel() {
		int height = 30;
		//��Ƭ����
		int photoNumber = PhotoMonitor.photoList.size();
		
		for (int i = photoNumber -1; i >= 0; --i) {
			JPanel photoPane = new JPanel();
			photoPane.setLayout(null);
			photoPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 180;
			int itemHeight = 150;
			int x = (itemWidth + 10) * ((photoNumber - 1 - i) % 3);
			int y = height;
			photoPane.setBounds(x, y, itemWidth, itemHeight);
			
			Photo photo = PhotoMonitor.photoList.get(i);
			//ͼƬ����
			////System.out.println(photo.getFileName());
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 170, showHeight = 120;
			try {
				FileInputStream src = new FileInputStream(new File(photo.getFileName()));
				BufferedImage   sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 120) {
					showWidth = 120*showWidth/showHeight;
					showHeight = 120;
				}
				if (showHeight < 120) {
					showWidth = 170*120/showHeight;
					showHeight = 120;
				}
				if (showWidth < 170) {
					showHeight = 120 * 170/showWidth;
					showWidth = 170;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+photo.getFileName()+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(5, 5, 170, 120);
			imgShow.setBounds((170-showWidth)/2, (120-showHeight)/2, showWidth, showHeight);
			
			final int p = i;
			
			imgShow.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						PhotoMonitor.viewPhoto(p);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			photoPane.add(frame);
			//ͼƬ��
			JLabel photoName = new JLabel(photo.getPhotoName());
			photoName.setBounds(5, 130, 130, 20);
			photoName.setForeground(SkinParameter.itemContent);
			photoName.setFont(new Font(null, Font.PLAIN, 12));
			photoPane.add(photoName);
			
			//����
			final String shs;
			if (photo.getAuthority() == Authority.isPublic) shs = "cancel_share.png";
			else shs = "share.png";
			UIPanel share = new UIPanel(18, 18, shs){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+shs);
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			share.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						PhotoMonitor.changePhotoAuthority(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			share.setBounds(140, 130, 18, 18);
			photoPane.add(share);
			
			//ɾ��һ����Ƭ
			UIPanel delete = new UIPanel(18, 18, "delete.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"delete.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			delete.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						PhotoMonitor.deletePhoto(p);
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			delete.setBounds(160, 130, 18, 18);
			photoPane.add(delete);
			
			//���ӻ������
			mainSceneInner.add(photoPane);
			if ((photoNumber - 1 - i) % 3 == 2 ) height += 180;
		}
		if (photoNumber % 3 > 0) height += 180;
		return height;
	}
	
	//��ȡ��ȷ�Ϻ����б�
	public static int setNeedListPanel() {
		
		//û�д�ȷ�Ϻ��ѣ�ֱ�ӷ���
		if (FriendMonitor.int1 == 0) return 0;
		
		//��ȷ�Ϻ��ѵ��б�
		JPanel confirm = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"needConfirm.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		confirm.setBounds(0,0,600,25);
		mainSceneInner.add(confirm);
		
		int height = 26;
		//��ȷ������
		int friendNumber = FriendMonitor.int1;
		for (int i = friendNumber -1; i >= 0; --i) {
			JPanel userPane = new JPanel();
			userPane.setLayout(null);
			userPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 600;
			int itemHeight = 140;
			int x = 0;
			int y = height;
			userPane.setBounds(x, y, itemWidth, itemHeight+4);
			
			//�û�ͷ��
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 100, showHeight = 100;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 100) {
					showWidth = 100*showWidth/showHeight;
					showHeight = 100;
				}
				if (showHeight < 100) {
					showWidth = 100*100/showHeight;
					showHeight = 100;
				}
				if (showWidth < 100) {
					showHeight = 100 * 100/showWidth;
					showWidth = 100;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(20, 20, 100, 100);
			imgShow.setBounds((100-showWidth)/2, (100-showHeight)/2, showWidth, showHeight);
			
			final int userId = FriendMonitor.intResult1.get(i);
			
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			userPane.add(frame);
			
			//�û���
			JLabel userName = new JLabel(FriendMonitor.strResult1.get(i));
			userName.setBounds(160, 20, 500, 20);
			userName.setForeground(SkinParameter.itemTitle);
			userName.setFont(new Font(null, Font.BOLD, 12));
			userPane.add(userName);
			
			//�û����
			JLabel userIntroduction = new JLabel("<html>"+FriendMonitor.strResult2.get(i)+"</html>");
			userIntroduction.setBounds(135, 30, 400, 100);
			userIntroduction.setForeground(SkinParameter.itemContent);
			userIntroduction.setFont(new Font(null, Font.PLAIN, 12));
			userPane.add(userIntroduction);
			
			//�û��Ա�
			final boolean gender = FriendMonitor.boolResult1.get(i).booleanValue();
			//System.out.println(gender);
			JPanel isGirl = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+(gender==true?"female.png":"male.png"));
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			isGirl.setBounds(135, 20, 16, 16);
			userPane.add(isGirl);
			
			//ȷ������
			UIPanel confirmFriend = new UIPanel(80, 30, "confirm_friend.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"confirm_friend.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			confirmFriend.bindMouseListener(confirmFriend);
			confirmFriend.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						FriendMonitor.addFriend(userId);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			confirmFriend.setBounds(480, 100, 80, 30);
			userPane.add(confirmFriend);
			
			//���ӻ������
			mainSceneInner.add(userPane);
			height += 146;
		}
		
		return height;
	}
	
	//��ȡ�����б�
	public static int setFriendListPanel(int oriHeight) {
		
		
		//û�к��ѣ�ֱ�ӷ���
		if (FriendMonitor.int1 == 0) return 0;
		
		//���ѵ��б�
		JPanel list = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"friendList.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		list.setBounds(0,oriHeight,600,25);
		mainSceneInner.add(list);
		
		int height = oriHeight + 26;
		//����
		int friendNumber = FriendMonitor.int1;
		for (int i = friendNumber -1; i >= 0; --i) {
			JPanel userPane = new JPanel();
			userPane.setLayout(null);
			userPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 600;
			int itemHeight = 144;
			int x = 0;
			int y = height;
			userPane.setBounds(x, y, itemWidth, itemHeight);
			
			//�û�ͷ��
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 100, showHeight = 100;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 100) {
					showWidth = 100*showWidth/showHeight;
					showHeight = 100;
				}
				if (showHeight < 100) {
					showWidth = 100*100/showHeight;
					showHeight = 100;
				}
				if (showWidth < 100) {
					showHeight = 100 * 100/showWidth;
					showWidth = 100;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(20, 20, 100, 100);
			imgShow.setBounds((100-showWidth)/2, (100-showHeight)/2, showWidth, showHeight);
			
			final int userId = FriendMonitor.intResult1.get(i);
			
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			userPane.add(frame);
			
			//�û���
			JLabel userName = new JLabel(FriendMonitor.strResult1.get(i));
			userName.setBounds(160, 20, 500, 20);
			userName.setForeground(SkinParameter.itemTitle);
			userName.setFont(new Font(null, Font.BOLD, 12));
			userPane.add(userName);
			
			//�û����
			JLabel userIntroduction = new JLabel("<html>"+FriendMonitor.strResult2.get(i)+"</html>");
			userIntroduction.setBounds(135, 30, 400, 100);
			userIntroduction.setForeground(SkinParameter.itemContent);
			userIntroduction.setFont(new Font(null, Font.PLAIN, 12));
			userPane.add(userIntroduction);
			
			//�û��Ա�
			final boolean gender = FriendMonitor.boolResult1.get(i).booleanValue();
			//System.out.println(gender);
			JPanel isGirl = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+(gender==true?"female.png":"male.png"));
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			isGirl.setBounds(135, 20, 16, 16);
			userPane.add(isGirl);
			
			//����
			UIPanel leaveMessage = new UIPanel(50, 25, "leave_message.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"leave_message.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			final String toUserName = FriendMonitor.strResult1.get(i);
			
			leaveMessage.bindMouseListener(leaveMessage);
			leaveMessage.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						SendMessage sendMessage = new SendMessage(userId,toUserName);
						sendMessage.setVisible(true);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			leaveMessage.setBounds(500, 100, 50, 25);
			userPane.add(leaveMessage);
			
			//���ӻ������
			mainSceneInner.add(userPane);
			height += 146;
		}
		
		return height;
	}
	
	//��ȡ�����б�
	public static int setMessagePanel() {
		
		//û�����ԣ�ֱ�ӷ���
		if (MessageMonitor.int1 == 0) return 0;
		
		int height = 0;
		//����
		int messageNumber = MessageMonitor.int1;
		for (int i = 0; i < messageNumber; ++i) {
			JPanel messagePane = new JPanel();
			messagePane.setLayout(null);
			messagePane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 600;
			int itemHeight = 100;
			int x = 0;
			int y = height;
			messagePane.setBounds(x, y, itemWidth, itemHeight+4);
			
			//�û�ͷ��
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 60, showHeight = 60;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 60) {
					showWidth = 60*showWidth/showHeight;
					showHeight = 60;
				}
				if (showHeight < 60) {
					showWidth = 60*60/showHeight;
					showHeight = 60;
				}
				if (showWidth < 60) {
					showHeight = 60 * 60/showWidth;
					showWidth = 60;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(20, 20, 60, 60);
			imgShow.setBounds((60-showWidth)/2, (60-showHeight)/2, showWidth, showHeight);
			
			final int userId = MessageMonitor.intResult1.get(i);
			
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			messagePane.add(frame);
			
			//�û���+ʱ��
			JLabel userName = new JLabel(MessageMonitor.strResult1.get(i)+" �� "+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format((long)MessageMonitor.intResult2.get(i)*(long)1000)+" ��������");
			userName.setBounds(100, 20, 500, 20);
			userName.setForeground(SkinParameter.itemTitle);
			userName.setFont(new Font(null, Font.BOLD, 12));
			messagePane.add(userName);
			
			//��������
			JLabel userIntroduction = new JLabel("<html>"+MessageMonitor.strResult2.get(i)+"</html>");
			userIntroduction.setBounds(100, 30, 430, 50);
			userIntroduction.setForeground(SkinParameter.itemContent);
			userIntroduction.setFont(new Font(null, Font.PLAIN, 12));
			messagePane.add(userIntroduction);
			
			//�ظ�
			UIPanel leaveMessage = new UIPanel(50, 25, "reply_message.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"reply_message.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			final String toUserName = MessageMonitor.strResult1.get(i);
			leaveMessage.bindMouseListener(leaveMessage);
			leaveMessage.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						SendMessage sendMessage = new SendMessage(userId,toUserName);
						sendMessage.setVisible(true);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			leaveMessage.setBounds(500, 60, 50, 25);
			messagePane.add(leaveMessage);
			
			//���ӻ������
			mainSceneInner.add(messagePane);
			height += 106;
		}
		
		return height;
	}
	
	//Ӧ�����
	public static int setAppPanel() {
		int height = 0;
		String path=System.getProperty("user.dir")+"/content/app/";
        File articlePath=new File(path);
        ArrayList<String> appList=new ArrayList<String>();
        File[] articles = articlePath.listFiles();
        for (int i=0; i<articles.length; ++i)
        	if (articles[i].getAbsolutePath().endsWith(".jar")){
        		appList.add(articles[i].getAbsolutePath());
        		//System.out.println(articles[i].getAbsolutePath());
        	}
        //��ʾӦ��
        //Ӧ������
		int appNumber = appList.size();
		//System.out.println(appNumber);
		for (int i = appNumber -1; i >= 0; --i) {
			int pos = appList.get(i).lastIndexOf("/");
			int pos2 = appList.get(i).lastIndexOf("\\");
			if (pos < pos2) pos = pos2;
			final String appName = appList.get(i).substring(pos + 1,appList.get(i).lastIndexOf("."));
			JPanel appPane = new JPanel();
			appPane.setLayout(null);
			appPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 140;
			int itemHeight = 155;
			int x = (itemWidth + 5) * ((appNumber - 1 - i) % 4);
			int y = height;
			appPane.setBounds(x+3, y+2, itemWidth+3, itemHeight);
			
			//ͼƬ����
			////System.out.println(photo.getFileName());
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 72, showHeight = 72;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/content/app/"+appName+".png"));
				BufferedImage   sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 72) {
					showWidth = 72*showWidth/showHeight;
					showHeight = 72;
				}
				if (showHeight < 72) {
					showWidth = 72*72/showHeight;
					showHeight = 72;
				}
				if (showWidth < 72) {
					showHeight = 72 * 72/showWidth;
					showWidth = 72;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/content/app/"+appName+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(15, 15, 110, 110);
			imgShow.setBounds((110-showWidth)/2, (110-showHeight)/2, showWidth, showHeight);
			
			final int p = i;
			
			imgShow.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						/**
						 * Need For Complete
						 * PhotoMonitor.viewPhoto(p);
						 */
						String command = "java -jar \""+System.getProperty("user.dir")+"/content/app/"+appName+".jar\"";
						System.out.println(command);
						try{
							Runtime.getRuntime().exec(command);
						}catch(Exception ex){
							System.err.println(ex.toString());
						}
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			appPane.add(frame);
			//Ӧ����
			JLabel appName2 = new JLabel(appName);
			appName2.setBounds(15, 130, 130, 20);
			appName2.setForeground(SkinParameter.itemTitle);
			appName2.setFont(new Font(null, Font.BOLD, 12));
			appPane.add(appName2);
			
			//ɾ��һ��Ӧ��
			UIPanel delete = new UIPanel(18, 18, "delete.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"delete.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			delete.bindMouseListener(delete);
			delete.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						/**
						 * Need For Complete
						 */
						File toDel = new File(System.getProperty("user.dir")+"/content/app/"+appName+".png");
						if (toDel.isFile()) toDel.delete();
						toDel = new File(System.getProperty("user.dir")+"/content/app/"+appName+".jar");
						if (toDel.isFile()) toDel.delete();
						
						resetMainBoard();
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			delete.setBounds(110, 130, 18, 18);
			appPane.add(delete);
			
			//���ӻ������
			mainSceneInner.add(appPane);
			if ((appNumber - 1 - i) % 4 == 3 ) height += 180;
		}
		if (appNumber % 4 > 0) height += 180;
        //===========
		return height;
	}
	//Add Page, Modify Here
	//������
	public static int setNewsPanel(){
		int height = 0;
		//System.out.println("done");
		//����������
		int newsNumber = NewsMonitor.int1;
		for (int i = 0; i<newsNumber; ++i) {
			//��Ϣ��
			JPanel newsPane = new JPanel();
			newsPane.setLayout(null);
			newsPane.setBackground(Color.white);

			//�û�ͷ��
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 60, showHeight = 60;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 60) {
					showWidth = 60*showWidth/showHeight;
					showHeight = 60;
				}
				if (showHeight < 60) {
					showWidth = 60*60/showHeight;
					showHeight = 60;
				}
				if (showWidth < 60) {
					showHeight = 60 * 60/showWidth;
					showWidth = 60;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(20, 20, 60, 60);
			imgShow.setBounds((60-showWidth)/2, (60-showHeight)/2, showWidth, showHeight);
			frame.add(imgShow);
			////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			newsPane.add(frame);
			
			//��������Ϣ���壺
			String title = "";
			if (NewsMonitor.boolResult1.get(i).booleanValue() == true){
				title +=NewsMonitor.strResult1.get(i)+" ת���� " + NewsMonitor.strResult2.get(i) +" ��";
				
			}else{
				title +=NewsMonitor.strResult2.get(i);
				if (NewsMonitor.boolResult2.get(i).booleanValue() == true)
					title +=" ������ ";else title+=" ������ ";
			}
			int deltaHeight = 120;
			if (NewsMonitor.strResult3.get(i).equals("article")) {
				title +="��־";
			}else
				if (NewsMonitor.strResult3.get(i).equals("photo")) {
					title +="��Ƭ";
					deltaHeight = 220;
				}else
					if (NewsMonitor.strResult3.get(i).equals("music")) {
						title +="����";
					}else
						if (NewsMonitor.strResult3.get(i).equals("video")) {
							title +="��Ƶ";
						}
			
			JLabel topLine = new JLabel(title);
			topLine.setBounds(100,15,500,20);
			topLine.setFont(new Font(null,Font.BOLD,14));
			topLine.setForeground(SkinParameter.itemTitle);
			newsPane.add(topLine);
			
			//ʱ��
			JLabel time = new JLabel(new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format((long)NewsMonitor.intResult2.get(i)*(long)1000));
			time.setBounds(100, 40, 150, 15);
			time.setFont(new Font(null, Font.ITALIC, 12));
			time.setForeground(SkinParameter.itemContent);
			newsPane.add(time);
			//final int userId = NewsMonitor.intResult1.get(i);
			//��ţ�ʱ��
			final int p = i;
			final long itemTime = (long)NewsMonitor.intResult2.get(i)*(long)1000;
			final String itemFileName = NewsMonitor.strResult5.get(i);
			final int fromId = NewsMonitor.intResult3.get(i);
			final String fromName = NewsMonitor.strResult2.get(i);
			final String oriName = NewsMonitor.strResult4.get(i);
			//����
			JLabel content = new JLabel(NewsMonitor.strResult5.get(i));
			content.setBounds(160, 65, 500, 20);
			content.setFont(new Font(null, Font.PLAIN, 14));
			content.setForeground(new Color(51,51,51));
			//ͼ��
			if (NewsMonitor.strResult3.get(i).equals("article")) {
				//����Logo
				JPanel logo = new JPanel(){
					public void paintComponent(Graphics g) {
						ImageIcon img = new ImageIcon(System.getProperty("user.dir")+"/skin/global/articleEditor_small.png");
				        g.drawImage(img.getImage(),0,0,null);
				    }
				};
				logo.setBounds(100, 60, 50, 50);
				newsPane.add(logo);
				
				newsPane.add(content);
				
				//�鿴����
				newsPane.addMouseListener(
					new MouseListener() {
						@Override
						public void mouseClicked(MouseEvent e) {
							DownloadMonitor.viewWebSource(p, fromId, "article", oriName);
							while (DownloadMonitor.isWorking) {
								try {
									Thread.sleep(100);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							}
							System.out.println("down Article");
							Article article = null;
							try {
								ObjectInputStream rw =new ObjectInputStream(new FileInputStream(System.getProperty("user.dir")+"/tmp/"+DownloadMonitor.strData1));
								article = (Article)rw.readObject();
								rw.close();
							}catch (Exception ex) {
								System.out.println(e.toString());
							}
							// TODO Auto-generated method stub
							ArticleViewer viewer = new ArticleViewer();
							viewer.theArticle = article;
							viewer.userName = fromName;
							viewer.submitTime = itemTime;
							viewer.init();
							Thread viewerTrd = new Thread(viewer);
							viewerTrd.start();
						}
						@Override
						public void mouseEntered(MouseEvent e) {}
						@Override
						public void mouseExited(MouseEvent e) {}
						@Override
						public void mousePressed(MouseEvent e) {}
						@Override
						public void mouseReleased(MouseEvent e) {}
					}
				);
			}else
				if (NewsMonitor.strResult3.get(i).equals("photo")) {
					//��ƬԤ��
					JLabel imgView = new JLabel();
					//width=170 height=120 
					showWidth = 170; showHeight = 120;
					try {
						FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+"_photo.png"));
						BufferedImage   sourceImg = ImageIO.read(src);
						showWidth = sourceImg.getWidth();
						showHeight = sourceImg.getHeight();
						src.close();
						if (showHeight > 120) {
							showWidth = 120*showWidth/showHeight;
							showHeight = 120;
						}
						if (showHeight < 120) {
							showWidth = 170*120/showHeight;
							showHeight = 120;
						}
						if (showWidth < 170) {
							showHeight = 120 * 170/showWidth;
							showWidth = 170;
						}
					}catch (Exception e) {	
					}
					imgView.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+"_photo.png"+"' width="+showWidth+" height="+showHeight+" /></html>");
					JPanel frame2 = new JPanel();
					frame2.setLayout(null);
					frame2.setBounds(100, 60, 170, 120);
					imgView.setBounds((170-showWidth)/2, (120-showHeight)/2, showWidth, showHeight);
					frame2.add(imgView);
					////System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
					newsPane.add(frame2);
					
					content.setBounds(100,185,400,20);
					content.setForeground(SkinParameter.photoViewerContent);
					newsPane.add(content);
					
					newsPane.addMouseListener(
						new MouseListener() {
							@Override
							public void mouseClicked(MouseEvent e) {
								// TODO Auto-generated method stub
								Thread trdViewer = new Thread(new WebPhotoViewer(p,System.getProperty("user.dir")+"/tmp/"+p+"_photo.png", oriName, itemFileName,itemTime, fromId));
								trdViewer.start();
							}
							@Override
							public void mouseEntered(MouseEvent e) {}
							@Override
							public void mouseExited(MouseEvent e) {}
							@Override
							public void mousePressed(MouseEvent e) {}
							@Override
							public void mouseReleased(MouseEvent e) {}
						}
					);
				}else
					if (NewsMonitor.strResult3.get(i).equals("music")) {
						//����Logo
						final String exp;
						if (NewsMonitor.strResult4.get(i).endsWith(".mp3")) exp = "mp3";else exp = "wav";
						JPanel logo = new JPanel(){
							public void paintComponent(Graphics g) {
								ImageIcon img = new ImageIcon(System.getProperty("user.dir")+"/skin/global/"+exp+"_small.png");
						        g.drawImage(img.getImage(),0,0,null);
						    }
						};
						logo.setBounds(100, 60, 50, 50);
						newsPane.add(logo);
						newsPane.add(content);
						
						//����Զ������
						newsPane.addMouseListener(
								new MouseListener() {
									@Override
									public void mouseClicked(MouseEvent e) {
										DownloadMonitor.viewWebSource(p, fromId, "music", oriName);
										while (DownloadMonitor.isWorking) {
											try {
												Thread.sleep(100);
											} catch (InterruptedException e1) {
												// TODO Auto-generated catch block
												e1.printStackTrace();
											}
										}
										System.out.println("down Music");
										// TODO Auto-generated method stub
										MusicMonitor.playWebMusic(System.getProperty("user.dir")+"/tmp/"+DownloadMonitor.strData1, itemFileName);
									}
									@Override
									public void mouseEntered(MouseEvent e) {}
									@Override
									public void mouseExited(MouseEvent e) {}
									@Override
									public void mousePressed(MouseEvent e) {}
									@Override
									public void mouseReleased(MouseEvent e) {}
								}
							);
					}else
						if (NewsMonitor.strResult3.get(i).equals("video")) {
							//��ƵLogo
							final String exp;
							if (NewsMonitor.strResult4.get(i).endsWith(".mpg")) exp = "mpg";else exp = "avi";
							JPanel logo = new JPanel(){
								public void paintComponent(Graphics g) {
									ImageIcon img = new ImageIcon(System.getProperty("user.dir")+"/skin/global/"+exp+"_small.png");
							        g.drawImage(img.getImage(),0,0,null);
							    }
							};
							logo.setBounds(100, 60, 50, 50);
							newsPane.add(logo);
							newsPane.add(content);
							
							//����Զ����Ƶ
							newsPane.addMouseListener(
									new MouseListener() {
										@Override
										public void mouseClicked(MouseEvent e) {
											DownloadMonitor.viewWebSource(p, fromId, "video", oriName);
											while (DownloadMonitor.isWorking) {
												try {
													Thread.sleep(100);
												} catch (InterruptedException e1) {
													// TODO Auto-generated catch block
													e1.printStackTrace();
												}
											}
											System.out.println("down Music");
											// TODO Auto-generated method stub
											VideoMonitor.playVideo(System.getProperty("user.dir")+"/tmp/"+DownloadMonitor.strData1);
										}
										@Override
										public void mouseEntered(MouseEvent e) {}
										@Override
										public void mouseExited(MouseEvent e) {}
										@Override
										public void mousePressed(MouseEvent e) {}
										@Override
										public void mouseReleased(MouseEvent e) {}
									}
								);
						}
			
			
			
			//
			
			newsPane.setBounds(0, height, 580, deltaHeight);
			mainSceneInner.add(newsPane);
			height += deltaHeight + 1;
		}
		
		
		return height;
	}
}
