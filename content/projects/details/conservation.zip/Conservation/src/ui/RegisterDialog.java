package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import trans.ConservationFactory;

@SuppressWarnings({ "serial", "unused" })
public class RegisterDialog extends JFrame{

	private JTextField username;
	private JPasswordField password;
	private JTextArea userIntroduction;
	private JCheckBox isBoy,isGirl;
	private ButtonGroup gender;
	private JPanel close;
	private UIPanel btnRegister;
	public RegisterDialog() {
		init();
		UIUniversal.ToCenter(this);
	}
	private void init() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/Conservation.png");
		this.setIconImage(im);
		this.setSize(400, 510);
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"register_background.png"), false);
		username = new JTextField(20);
		username.setFont(new Font(null, Font.PLAIN, 16));
		username.setBounds(150, 90,200,30);
		username.setBorder(BorderFactory.createLineBorder(Color.white));
		
		password = new JPasswordField(20);
		password.setFont(new Font(null, Font.PLAIN, 16));
		password.setBounds(150, 160,200,30);
		password.setBorder(BorderFactory.createLineBorder(Color.white));

		userIntroduction = new JTextArea(20,15);
		userIntroduction.setFont(new Font(null, Font.PLAIN, 16));
		userIntroduction.setBounds(150, 230,200,100);
		userIntroduction.setBorder(BorderFactory.createLineBorder(Color.white));
		
		isBoy = new JCheckBox("");
		isBoy.setFont(new Font(null, Font.PLAIN, 16));
		isBoy.setBounds(150, 370,15,15);
		isBoy.setBorder(BorderFactory.createLineBorder(Color.white));
		isBoy.setSelected(true);
		
		isGirl = new JCheckBox("");
		isGirl.setFont(new Font(null, Font.PLAIN, 16));
		isGirl.setBounds(240, 370,15,15);
		isGirl.setBorder(BorderFactory.createLineBorder(Color.white));
		
		gender = new ButtonGroup();
		gender.add(isBoy);gender.add(isGirl);
		
		this.add(username);this.add(password);this.add(userIntroduction);
		this.add(isBoy);this.add(isGirl);
		
		close = new JPanel(){

			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(363, 5, 32, 32);

		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		
		this.add(close);
		
		btnRegister = new UIPanel(100, 35, "submit_register.png"){

			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"submit_register.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		btnRegister.setLocation(150, 435);
		btnRegister.bindMouseListener(btnRegister);
		
		btnRegister.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					String userName = username.getText();
					String userPassword = new String(password.getPassword());
					String introduction = userIntroduction.getText();
					boolean gender = false;
					if (isGirl.isSelected()) gender = true;
					if (userName.length() == 0) {
						JOptionPane.showMessageDialog(null, "�������û���", "����", JOptionPane.ERROR_MESSAGE);
						return;
					}
					if (userPassword.length() < 6) {
						JOptionPane.showMessageDialog(null, "��������Ϊ6λ", "����", JOptionPane.ERROR_MESSAGE);
						return;
					}
					ConservationFactory.registerUser(userName,userPassword,introduction,gender);
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		this.add(btnRegister);
		
	}
}


