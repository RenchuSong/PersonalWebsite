package ui;

import global.NowPage;
import global.SkinParameter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import trans.AppMonitor;
import trans.ConservationFactory;
import trans.FriendMonitor;

@SuppressWarnings({ "unused", "serial" })
public class DownloadApp extends JFrame{
	private JPanel close,mainSceneInner;
	private JTextField appName;
	private UIPanel search;
	private JScrollPane mainScene;
	
	public DownloadApp() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/app.png");
		this.setIconImage(im);
		this.setSize(600,450);
		this.setTitle("Conservation - ����Ӧ��");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"download_app.png"), false);
		
		//Ӧ����
		appName = new JTextField();
		appName.setBounds(15, 30, 500, 20);
		appName.setBorder(BorderFactory.createLineBorder(Color.white));
		add(appName);
		//������ť
		search = new UIPanel(20, 20, "search.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"search.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		search.setBounds(515,30,20,20);
		search.bindMouseListener(search);
		search.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					//����Ӧ���б�
					loadList();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		add(search);
		//�����
		mainSceneInner = new JPanel();
		mainSceneInner.setSize(580, 100);
		mainSceneInner.setLayout(null);
		Dimension d = new Dimension(580,100);
		mainSceneInner.setPreferredSize(d);
		mainScene = new JScrollPane(mainSceneInner, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainScene.setBounds(10, 60, 580, 370);
		add(mainScene);
		validate();

		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(563, 5, 32, 32);
		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		UIUniversal.ToCenter(this);
	}
	//����Ӧ��
	public void loadList() {
		
		if (mainSceneInner!= null)
			mainScene.remove(mainSceneInner);
		if (mainScene!=null)
			remove(mainScene);
		mainSceneInner = new JPanel();
		
		if (ConservationFactory.client2server.connected == false) {
			mainSceneInner.removeAll();
			UIPanel disconnect = new UIPanel(600, 480, "disconnect.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"disconnect.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			disconnect.setBounds(0, -50, 600, 480);
			mainSceneInner.add(disconnect);
			mainSceneInner.setSize(580, 360);
			Dimension d = new Dimension(580,360);
			mainSceneInner.setPreferredSize(d);
		}else {
		
			AppMonitor.searchApp(appName.getText().trim());
			while (AppMonitor.isWorking)
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		int height = 0;
		
		int appNumber = AppMonitor.int1;
		for (int i = appNumber -1; i >= 0; --i) {
			
			int pos = AppMonitor.strResult1.get(i).lastIndexOf("/");
			int pos2 = AppMonitor.strResult1.get(i).lastIndexOf("\\");
			if (pos < pos2) pos = pos2;
			final String appName = AppMonitor.strResult1.get(i);
			JPanel appPane = new JPanel();
			appPane.setLayout(null);
			appPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 140;
			int itemHeight = 155;
			int x = (itemWidth + 5) * ((appNumber - 1 - i) % 4);
			int y = height;
			appPane.setBounds(x, y, itemWidth, itemHeight);
			
			//ͼƬ����
			//System.out.println(photo.getFileName());
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 72, showHeight = 72;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage   sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 72) {
					showWidth = 72*showWidth/showHeight;
					showHeight = 72;
				}
				if (showHeight < 72) {
					showWidth = 72*72/showHeight;
					showHeight = 72;
				}
				if (showWidth < 72) {
					showHeight = 72 * 72/showWidth;
					showWidth = 72;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(15, 15, 110, 110);
			imgShow.setBounds((110-showWidth)/2, (110-showHeight)/2, showWidth, showHeight);
			
			final int p = i;
			
			frame.add(imgShow);
			//System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			appPane.add(frame);
			//Ӧ����
			JLabel appName2 = new JLabel(appName);
			appName2.setBounds(15, 130, 130, 20);
			appName2.setForeground(SkinParameter.itemTitle);
			appName2.setFont(new Font(null, Font.BOLD, 12));
			appPane.add(appName2);
			
			//ɾ��һ��Ӧ��
			UIPanel download = new UIPanel(18, 18, "download.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"download.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			download.bindMouseListener(download);
			download.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						/**
						 * Need For Complete
						 */
						AppMonitor.downloadApp(appName);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			download.setBounds(110, 130, 18, 18);
			appPane.add(download);
			
			//���ӻ������
			mainSceneInner.add(appPane);
			if ((appNumber - 1 - i) % 4 == 3 ) height += 180;
		}
		if (appNumber % 4 > 0) height += 180;
		
		mainSceneInner.setSize(580, height);
		Dimension d = new Dimension(580,height);
		mainSceneInner.setPreferredSize(d);
		}
		mainSceneInner.setLayout(null);
		mainScene = new JScrollPane(mainSceneInner, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainScene.setBounds(10, 60, 580, 370);
		add(mainScene);
		validate();
	}
}
