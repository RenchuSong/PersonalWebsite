package ui;

import global.SkinParameter;

import javax.swing.*; 

import java.awt.*; 
import java.awt.event.*; 

import javax.swing.event.*; 
import javax.swing.border.*;
import java.io.File.*;
import java.io.*;
import javax.media.ControllerClosedEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.EndOfMediaEvent;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.media.PrefetchCompleteEvent;
import javax.media.RealizeCompleteEvent;
import javax.media.Time; 

import trans.ConservationFactory;
import trans.MusicMonitor;

import java.beans.*;

@SuppressWarnings({ "serial", "unused", "restriction" })
public class MusicPlayer extends JFrame implements Runnable{ 
	public static int musicIndex = 0;
	public static String path = ""; 
	public static Player player;
	private JPanel close;
	public UIPanel play,stop,pre,next;
	public CardLayout card;
	public JPanel playstop;
	private JLabel nowMusic, musicLength;
	private int theLength;
	private JPanel processBar;
	private boolean stoped = false;
	private ScrollBar moveScrollBar;
	private Thread trdScrollBar;
	int x,y;
	
	public MusicPlayer() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/MusicPlayer.png");
		this.setIconImage(im);
		this.setSize(500,200);
		this.setTitle("Conservation - ���ֲ�����");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"player.png"), false);
		
		card = new CardLayout();
		playstop = new JPanel();
		playstop.setBackground(Color.white);
		playstop.setLayout(card);
		playstop.setBounds(214, 120, 72, 72);
		//���Ű�ť
		play = new UIPanel(72, 72, "play_big.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"play_big.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		play.setBounds(0, 0, 72, 72);
		//play.bindMouseListener(play);
		play.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					card.show(playstop, "stop");
					playMusic();
					playstop.revalidate();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		playstop.add("play",play);
		
		//ֹͣ��ť
		stop = new UIPanel(72, 72, "stop_big.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"stop_big.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		stop.setBounds(214, 120, 72, 72);
		//stop.bindMouseListener(stop);
		stop.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					card.show(playstop, "play");
					player.stop();
					moveScrollBar.stoped = true;
					playstop.revalidate();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		playstop.add("stop",stop);
		
		this.add(playstop);
		
		//ǰһ�װ�ť
		pre = new UIPanel(48, 48, "previous.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"previous.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		pre.setBounds(164, 132, 48, 48);
		//stop.bindMouseListener(stop);
		pre.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					preMusic();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		//��һ�װ�ť
		next = new UIPanel(48, 48, "next.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"next.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		next.setBounds(286, 132, 48, 48);
		//stop.bindMouseListener(stop);
		next.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					nextMusic();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		this.add(pre);this.add(next);
		
		//������
		processBar = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"process_bar.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		processBar.setBounds(35, 80, 15, 35);
		this.add(processBar);
		
		//��ǰ�����ͳ���
		nowMusic = new JLabel();
		nowMusic.setForeground(SkinParameter.playerMusicName);
		nowMusic.setFont(new Font(null, Font.BOLD, 20));
		nowMusic.setBounds(30, 40, 480, 20);
		this.add(nowMusic);
		musicLength = new JLabel();
		musicLength.setForeground(SkinParameter.playerMusicLength);
		musicLength.setFont(new Font(null, Font.ITALIC, 12));
		musicLength.setBounds(350, 42, 200, 20);
		this.add(musicLength);
		
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(463, 5, 32, 32);
		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				player.close();
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
	}
	//��������
	public void playMusic() {
		card.show(playstop, "stop");
		player.prefetch();
		player.setMediaTime(new Time(0.0));
		player.start();
		
		if (moveScrollBar != null)
			moveScrollBar.stoped = true;
		
		moveScrollBar = new ScrollBar(processBar);
		moveScrollBar.waitItem = theLength;
		moveScrollBar.stoped = false;
		//if (trdScrollBar == null || !trdScrollBar.isAlive())
		trdScrollBar = new Thread(moveScrollBar);
		
		trdScrollBar.start();
		/*processBar.setLocation(35, 80);
		for (int i = 0; i < 1000; ++i) {
			if (stoped) {
				processBar.setLocation(35, 80);
				i = 0;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
			}
			processBar.setLocation(35 + i*415/1000, 80);
			try {
				Thread.sleep(theLength);
			} catch (InterruptedException e) {
			}
		}*/
	}
	//��һ��
	public void nextMusic() {
		musicIndex ++;
		if (musicIndex >= MusicMonitor.musicList.size()) musicIndex = 0;
		player.close();
		path = MusicMonitor.musicList.get(musicIndex).getFileName();
		buildPlayer();
		playMusic();
	}
	//ǰһ��
	public void preMusic() {
		musicIndex --;
		if (musicIndex < 0) musicIndex = MusicMonitor.musicList.size() -1;
		player.close();
		path = MusicMonitor.musicList.get(musicIndex).getFileName();
		buildPlayer();
		playMusic();
	}
	
	//���¹���������
	public void buildPlayer() {
		if (player!=null)
			player.stop();
		File f1 = new File(path); 
		try { 
			player = Manager.createRealizedPlayer(f1.toURI().toURL()); 
			nowMusic.setText(MusicMonitor.musicList.get(musicIndex).getMusicName());
			theLength = (int) player.getDuration().getSeconds();
			musicLength.setText("�������ȣ�"+(theLength/60<10?"0":"")+(theLength/60)+":"+(theLength % 60<10?"0":"")+(theLength %60));
		}catch(Exception ex){
			System.out.println(ex);
		} 
	}
	//���¹������粥����
	@SuppressWarnings("static-access")
	public void buildWebPlayer(String path, String name) {
		if (player!=null)
			player.stop();
		this.path = path;
		File f1 = new File(path); 
		try { 
			player = Manager.createRealizedPlayer(f1.toURI().toURL()); 
			nowMusic.setText(name);
			theLength = (int) player.getDuration().getSeconds();
			musicLength.setText("�������ȣ�"+(theLength/60<10?"0":"")+(theLength/60)+":"+(theLength % 60<10?"0":"")+(theLength %60));
		}catch(Exception ex){
			System.out.println(ex);
		} 
	}
	
	//����
	@Override
	public void run() {
		// TODO Auto-generated method stub
		int x = this.getX() + 550;
		int dx = 100;
		int y = this.getY();
		this.setLocation(x , y);
		this.setVisible(true);
		for (int i = 0; i< 10; ++i) {
			x -= dx;
			dx -= 10;
			this.setLocation(x , y);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			}
		}
		this.playMusic();
	} 
}

class ScrollBar implements Runnable {

	JPanel scrollBar;
	public int waitItem = 0;
	public boolean stoped = false;
	
	ScrollBar(JPanel scrollBar) {
		this.scrollBar =scrollBar;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		scrollBar.setLocation(35, 80);
		for (int i = 0; i < 1000; ++i) {
			if (stoped) {
				scrollBar.setLocation(35, 80);
				return;
			}
			scrollBar.setLocation(35 + i*415/1000, 80);
			try {
				Thread.sleep(waitItem);
			} catch (InterruptedException e) {
			}
		}
		scrollBar.setLocation(35, 80);
		MusicMonitor.musicPlayer.card.show(MusicMonitor.musicPlayer.playstop, "play");
	}
}