package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import global.Article;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import trans.ConservationFactory;

@SuppressWarnings({ "serial", "unused" })
public class ArticleViewer extends JFrame implements Runnable{
	Article theArticle;
	long submitTime;
	private JPanel close;
	String userName;
	int x,y;
	
	public ArticleViewer() {
		
	}
	
	public ArticleViewer(Article article, String fileName, String userName) {
		theArticle = article;
		this.submitTime = Long.parseLong(fileName.substring((System.getProperty("user.dir")+"/content/article/").length(), fileName.length() - 5));
		this.userName = userName;
		init();
	}
	
	protected void init() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/ArticleViewer.png");
		this.setIconImage(im);
		this.setSize(600,640);
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(563, 5, 32, 32);
		
		x = this.getX(); y = this.getY();
		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				//ConservationFactory.writeBack();
				int dx = 10;
				setLocation(x , y);
				for (int i = 0; i< 10; ++i) {
					x += dx;
					dx += 10;
					setLocation(x , y);
					try {
						Thread.sleep(50);
					} catch (InterruptedException ex) {
						// TODO Auto-generated catch block
					}
				}
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		
		String user_time = "";
		if (userName!=null) user_time = userName + " ";
		user_time += "�����ڣ�"+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format(submitTime);
		JLabel sTime = new JLabel(user_time);
		sTime.setBounds(10, 70, 500, 20);
		sTime.setFont(new Font(null, Font.ITALIC, 14));
		
		JPanel bgColor = new JPanel();
		bgColor.setBounds(0, 0, 600, 640);
		bgColor.setBackground(theArticle.backColor);
		bgColor.setLayout(null);
		bgColor.add(close);
		bgColor.setBorder(BorderFactory.createLineBorder(Color.black));
		bgColor.add(sTime);
		
		JLabel title = new JLabel(theArticle.title);
		title.setBounds(10, 40, 580, 30);
		title.setFont(new Font(null, Font.BOLD, 26));
		title.setForeground(new Color(26, 105, 173));
		bgColor.add(title);
		JTextArea content = new JTextArea(theArticle.content);
		content.setLineWrap(true);
		int style = 0;
		if (theArticle.bold) style +=Font.BOLD;
		if (theArticle.italic) style +=Font.ITALIC;
		content.setFont(new Font(theArticle.fontName, style, theArticle.fontSize));
		content.setEditable(false);
		int width = 580;
		int height = 520;
		content.setBounds(0,0, width, height);
		content.setForeground(theArticle.color);
		content.setBackground(theArticle.backColor);
		JScrollPane scp = new JScrollPane(content, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scp.setBorder(BorderFactory.createLineBorder(theArticle.backColor));
		scp.setBounds(10, 100, 580, 520);
		bgColor.add(scp);
		this.add(bgColor);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int x = this.getX() + 550;
		int dx = 100;
		int y = this.getY();
		this.setLocation(x , y);
		this.setVisible(true);
		for (int i = 0; i< 10; ++i) {
			x -= dx;
			dx -= 10;
			this.setLocation(x , y);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			}
		}
	}
}
