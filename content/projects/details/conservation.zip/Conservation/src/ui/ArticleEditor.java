package ui;
import global.Article;
import global.Authority;
import global.ItemType;
import global.TransType;
import global.Transaction;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import trans.ArticleMonitor;
import trans.TransMonitor;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.text.DateFormat;
import java.util.*;

@SuppressWarnings({ "serial", "unused" })
public class ArticleEditor extends JFrame {
	//��־���󣬳�ʼ������
	public Article theArticle;
	
	//Menu Bar and sub items
	JMenuBar theBar;
	JMenu edit;
	JMenuItem redo,cut,copy,paste,find,replace,selAll,dateTime;
	//Tool Bar and sub items
	JPanel toolbar;
	JButton b_time, b_selAll, b_find,b_replace,b_cut,b_copy,b_paste,b_redo;
	JComboBox fontName;
	JTextField fontSize,title;
	JButton bold,italic,fontColor,backColor, submitArticle;
	JTextArea scene;
	JPopupMenu popMenu;
	JFileChooser fileChooser = new JFileChooser();
	JCheckBox authority;
	
	//Logical variants
	boolean textChanged = false;
	Stack<Article> history = new Stack<Article>();
	boolean nowBold = false,nowItalic = false;
	String nowFontName;
	Color nowColor = Color.black;
	Color nowBackColor = Color.white;
	int nowFontSize = 12;
	String saveName = null;
	Article preArticle;
	boolean nowEnter = true;
	URL url;
	int fontNameNumber;
	String nowContent;
	Authority originAuthority;
	
	public ArticleEditor(Article theArticle, String fileFullName) {
		super("Conservation - ��־�༭��");
		this.theArticle = theArticle;
		
		setUI();
		setMenuBar();
		createToolBar();
		createScene();
		if (this.theArticle == null) {
			submitArticle.setText("������־");
			this.theArticle = new Article(nowFontName,nowFontSize,nowBold,nowItalic,nowColor,nowBackColor,"","", Authority.isPublic);
			preArticle = new Article(nowFontName,nowFontSize,nowBold,nowItalic,nowColor,nowBackColor,"","", Authority.isPublic);
		}else {
			submitArticle.setText("�����޸�");
			updateUIFromArticle();
			preArticle = new Article(nowFontName,nowFontSize,nowBold,nowItalic,nowColor,nowBackColor,title.getText(),scene.getText(), theArticle.authority);
		}
		nowContent = this.theArticle.content;
		originAuthority = this.theArticle.authority;
		
		saveName = fileFullName;
		setEventListener();
		history.push(theArticle);
		setVisible(true);
		//To Change
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
	//�ӽ������theArticle��������
	private void updateArticle() {
		theArticle.fontName = nowFontName;
		theArticle.fontSize = nowFontSize;
		theArticle.bold = nowBold;
		theArticle.italic = nowItalic;
		theArticle.color = nowColor;
		theArticle.backColor = nowBackColor;
		theArticle.title = title.getText();
		theArticle.content = scene.getText();
		if (authority.isSelected()) 
			theArticle.authority = Authority.isPrivate;
		else 
			theArticle.authority = Authority.isPublic;
	}
	//��Article���½��棨�ָ�ʱ�ã�
	private void updateUIFromArticle() {
		nowFontName = this.theArticle.fontName;
		nowBold = this.theArticle.bold;
		nowItalic = this.theArticle.italic;
		nowFontSize = this.theArticle.fontSize;
		fontSize.setText(String.valueOf(nowFontSize));
		int style = 0;
		if (nowBold) style += Font.BOLD;
		if (nowItalic) style += Font.ITALIC;
		Font f = new Font(nowFontName,style, nowFontSize);
		scene.setFont(f);
		for (int i=0;i<fontNameNumber;++i){
			if (((String)fontName.getItemAt(i)).equalsIgnoreCase(nowFontName)){
					fontName.setSelectedIndex(i);
			}
		}
		if (nowBold) bold.setBackground(Color.yellow);else bold.setBackground(null);
		if (nowItalic) italic.setBackground(Color.yellow);else italic.setBackground(null);
		nowColor = this.theArticle.color;
		nowBackColor = this.theArticle.backColor;
		scene.setText(this.theArticle.content);
		scene.setBackground(this.theArticle.backColor);
		scene.setForeground(this.theArticle.color);
		title.setText(this.theArticle.title);
		if (this.theArticle.authority == Authority.isPrivate)
			authority.setSelected(true);
		else
			authority.setSelected(false);
	}
	
	//========================UI Section==============================
	private void setUI() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/ArticleEditor.png");
		this.setIconImage(im);
		setBounds(0,0,600,500);
		UIUniversal.ToCenter(this);
	}
	
	private void setMenuBar() {
		theBar = new JMenuBar();
		edit = new JMenu("�ı�����(O)");
		edit.setMnemonic('O');
		redo = new JMenuItem("����(U)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/redo.png"));
		redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
		cut = new JMenuItem("����(T)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/cut.png"));
		cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
		copy = new JMenuItem("����(C)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/copy.png"));
		copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
		paste = new JMenuItem("ճ��(P)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/paste.png"));
		paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
		find = new JMenuItem("����(F)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/find.png"));
		find.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		replace = new JMenuItem("�滻(R)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/replace.png"));
		replace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_MASK));
		selAll = new JMenuItem("ȫѡ(A)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/selAll.png"));
		selAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
		dateTime = new JMenuItem("ʱ��/����(D)", new ImageIcon(System.getProperty("user.dir")+"/skin/global/dateTime.png"));
		dateTime.setAccelerator(KeyStroke.getKeyStroke("F5"));
		edit.add(redo);
		edit.addSeparator();
		edit.add(cut);
		edit.add(copy);
		edit.add(paste);
		edit.addSeparator();
		edit.add(find);
		edit.add(replace);
		edit.addSeparator();
		edit.add(selAll);
		edit.add(dateTime);
		theBar.add(edit);
		
		popMenu = edit.getPopupMenu();
		
		setJMenuBar(theBar);
	}
	
	private void createToolBar() {
		toolbar = new JPanel();
		toolbar.setLayout(null);
		JLabel lrc = new JLabel("��־���⣺");
		lrc.setBounds(7, 7, 70, 25);
		lrc.setFont(new Font("����",Font.BOLD,12));
		toolbar.add(lrc);
		title = new JTextField();
		title.setBounds(75,8,505,25);
		toolbar.add(title);
		ImageIcon im;
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/dateTime.png");
		b_time = new JButton(im);
		b_time.setBounds(5, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/selAll.png");
		b_selAll = new JButton(im);
		b_selAll.setBounds(25, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/find.png");
		b_find = new JButton(im);
		b_find.setBounds(50, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/replace.png");
		b_replace = new JButton(im);
		b_replace.setBounds(70, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/cut.png");
		b_cut = new JButton(im);
		b_cut.setBounds(95, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/copy.png");
		b_copy = new JButton(im);
		b_copy.setBounds(115, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/paste.png");
		b_paste = new JButton(im);
		b_paste.setBounds(135, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/redo.png");
		b_redo = new JButton(im);
		b_redo.setBounds(155, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/bold.png");
		bold = new JButton(im);
		bold.setBounds(180, 40, 20, 20);
		im = new ImageIcon(System.getProperty("user.dir")+"/skin/global/italic.png");
		italic = new JButton(im);
		italic.setBounds(200, 40, 20, 20);

		fontName = new JComboBox();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		String[] fontNameList = ge.getAvailableFontFamilyNames();
		for (String str: fontNameList)
			fontName.addItem(str);
		nowFontName = fontNameList[0];
		fontNameNumber = fontNameList.length;
		for (int i=0;i<fontNameNumber;++i){
			if (((String)fontName.getItemAt(i)).equalsIgnoreCase("����")){
					fontName.setSelectedIndex(i);
					nowFontName = fontNameList[i];
			}
		}
		fontName.setBounds(265, 40, 100, 20);
		fontSize = new JTextField("12");
		fontSize.setBounds(370,40,50,21);
		fontColor = new JButton(new ImageIcon(System.getProperty("user.dir")+"/skin/global/color.png"));
		fontColor.setBounds(220,40,20,20);
		
		backColor = new JButton(new ImageIcon(System.getProperty("user.dir")+"/skin/global/color.png"));
		backColor.setBackground(Color.orange);
		backColor.setBounds(240,40,20,20);
		
		submitArticle = new JButton();
		submitArticle.setBackground(new Color(26, 105, 173));
		submitArticle.setForeground(Color.white);
		submitArticle.setBounds(488,40,90,20);
		
		authority = new JCheckBox("˽��");
		authority.setBounds(425,40,60,20);
		
		toolbar.add(authority);
		toolbar.add(b_time);
		toolbar.add(b_selAll);
		toolbar.add(b_cut);
		toolbar.add(b_copy);
		toolbar.add(b_paste);
		toolbar.add(b_find);
		toolbar.add(b_replace);
		toolbar.add(b_redo);
		toolbar.add(bold);
		toolbar.add(italic);
		toolbar.add(fontName);
		toolbar.add(fontSize);
		toolbar.add(fontColor);
		toolbar.add(backColor);
		toolbar.add(submitArticle);
		
		add(toolbar, BorderLayout.NORTH);
		Dimension d = new Dimension(2000,65);
		toolbar.setPreferredSize(d);
	}
	
	JScrollPane panel;
	public void createScene() {
		scene = new JTextArea();
		scene.setLineWrap(true);
        panel = new JScrollPane(scene,
          ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
          ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scene.setFont(new Font(nowFontName,Font.PLAIN, nowFontSize));

        add(panel, BorderLayout.CENTER);
	}
	
	private void setEventListener() {
		//Close File
		addWindowListener(
			new WindowAdapter() {
				public void windowClosing(WindowEvent e) {
					popMenu.setVisible(false);
					closeFile();
				}
			}
		);
		redo.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					redoChange();
					popMenu.setVisible(false);
				}
			}
		);	
		b_redo.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						redoChange();
						popMenu.setVisible(false);
					}
				}
			);	
		
		cut.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scene.cut();
					checkChange();
					popMenu.setVisible(false);
				}
			}
		);
		b_cut.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						scene.cut();
						checkChange();
						popMenu.setVisible(false);
					}
				}
			);
		
		copy.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scene.copy();
					checkChange();
					popMenu.setVisible(false);
				}
			}
		);
		b_copy.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						scene.copy();
						checkChange();
						popMenu.setVisible(false);
					}
				}
			);
		
		paste.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scene.paste();
					checkChange();
					popMenu.setVisible(false);
				}
			}
		);
		b_paste.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						scene.paste();
						checkChange();
						popMenu.setVisible(false);
					}
				}
			);
		
		selAll.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scene.selectAll();
					scene.requestFocus();
					popMenu.setVisible(false);
				}
			}
		);
		b_selAll.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						scene.selectAll();
						scene.requestFocus();
						popMenu.setVisible(false);
					}
				}
			);
		//Font Family Changed
		fontName.addItemListener(
			new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					popMenu.setVisible(false);
					nowFontName = fontName.getSelectedItem().toString();
					changeFont();
					checkChange();
				}
			}
		);
		//Bold or Not
		bold.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					if (!nowBold) {
						bold.setBackground(Color.yellow);
						nowBold = true;
					}else {
						bold.setBackground(redo.getBackground());
						nowBold = false;
					}
					changeFont();
					checkChange();
				}
			}
		);
		
		//Italic or Not
		italic.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					if (!nowItalic) {
						italic.setBackground(Color.yellow);
						nowItalic = true;
					}else {
						italic.setBackground(redo.getBackground());
						nowItalic = false;
					}
					changeFont();
					checkChange();
				}
			}
		);
		
		//Font Size
		fontSize.addKeyListener(
			new KeyListener() {
				public void keyPressed(KeyEvent e) {
					if (e.getKeyCode() == KeyEvent.VK_ENTER) {
						popMenu.setVisible(false);
						try {
							nowFontSize = Integer.valueOf(fontSize.getText().trim());
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null, "�ֺű���Ϊ������", "����", JOptionPane.ERROR_MESSAGE);
							nowFontSize = 12;
							fontSize.setText("12");
						}
						changeFont();
						checkChange();
					}
				}
				public void keyTyped(KeyEvent e){}
				public void keyReleased(KeyEvent e){}
			}
		);
		
		//Font Color
		fontColor.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					Color newColor = JColorChooser.showDialog(null, "��ɫѡ��", nowColor);
					if (newColor!=null) nowColor = newColor;
					changeFont();
					checkChange();
				}
			}
		);
		backColor.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					Color newColor = JColorChooser.showDialog(null, "��ɫѡ��", nowBackColor);
					if (newColor!=null) nowBackColor = newColor;
					scene.setBackground(nowBackColor);
					checkChange();
				}
			}
		);
		
		//Search
		find.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					searchDialog();
				}
			}
		);
		b_find.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						popMenu.setVisible(false);
						searchDialog();
					}
				}
			);
		
		//Replace
		replace.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					replaceDialog();
					checkChange();
				}
			}
		);
		b_replace.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						popMenu.setVisible(false);
						replaceDialog();
						checkChange();
					}
				}
			);
		
		//DateTime
		dateTime.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					popMenu.setVisible(false);
					scene.cut();
					Date now = new Date();
					DateFormat d2 = DateFormat.getDateTimeInstance();
					scene.insert(d2.format(now), scene.getCaretPosition());
					checkChange();
				}
			}
		);
		b_time.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						popMenu.setVisible(false);
						scene.cut();
						Date now = new Date();
						DateFormat d2 = DateFormat.getDateTimeInstance();
						scene.insert(d2.format(now), scene.getCaretPosition());
						checkChange();
					}
				}
			);
		//Scene Clicked
		scene.addMouseListener(
			new MouseAdapter(){ 
				public void mouseReleased(MouseEvent e) {
					if (e.getButton() == MouseEvent.BUTTON3) {
						popMenu.show(edit,e.getX()+scene.getX(),e.getY()+scene.getY() + 100);
					}
				}
				
				public void mouseClicked(MouseEvent e) {
					if (e.getButton() == MouseEvent.BUTTON1) {
						popMenu.setVisible(false);
					}
				}
			});
		authority.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						popMenu.setVisible(false);
						checkChange();
					}
				}
			);
		//Save Article
		submitArticle.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						popMenu.setVisible(false);
						saveFile();
						if (submitArticle.getText() == "������־")
							dispose();
					}
				}
			);
		//Scene Key Pressed
		scene.addKeyListener(
			new KeyListener() {

				@Override
				public void keyTyped(KeyEvent e) {
					checkChange();
				}

				@Override
				public void keyPressed(KeyEvent e) {
					checkChange();
				}

				@Override
				public void keyReleased(KeyEvent e) {
					checkChange();
				}
				
			}
		);
		title.addKeyListener(
				new KeyListener() {

					@Override
					public void keyTyped(KeyEvent e) {
						checkChange();
					}

					@Override
					public void keyPressed(KeyEvent e) {
						checkChange();
					}

					@Override
					public void keyReleased(KeyEvent e) {
						checkChange();
					}
					
				}
			);
	}
	
	//=======================Logic Section=============================
	//Close File 
	private void closeFile() {
		boolean needChange = false;
		if (theArticle.bold!=nowBold) needChange = true;
		if (theArticle.italic!=nowItalic) needChange = true;
		if (theArticle.backColor.getRGB()!=nowBackColor.getRGB()) needChange = true;
		if (theArticle.color.getRGB()!=nowColor.getRGB()) needChange = true;
		if (!theArticle.content.equals(scene.getText())) needChange = true;
		if (!theArticle.title.equals(title.getText())) needChange = true;
		if (theArticle.fontName!=nowFontName) needChange = true;
		if (theArticle.fontSize!=nowFontSize) needChange = true;
		if (theArticle.authority == Authority.isPrivate && !authority.isSelected()) needChange = true;
		if (theArticle.authority == Authority.isPublic && authority.isSelected()) needChange = true;
		
		if (needChange || textChanged) {
			requestSave();
			if (message == 2) dispose();
			if (message == 1) {
				if (saveFile())
					dispose();
			}
			if (message == 0) return;
		} else dispose();
	}

	//Save File
	private boolean saveFile() {
		if (saveName == null) {
			return false;
		}
		updateArticle();
		if (theArticle.title.trim().equals("")) {
			JOptionPane.showMessageDialog(this, "��־���ⲻ��Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (theArticle.content.trim().equals("")) {
			JOptionPane.showMessageDialog(this, "��־���ݲ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		try {
			ObjectOutputStream bw =new ObjectOutputStream(new FileOutputStream(saveName));
			bw.writeObject(this.theArticle);
			bw.close();
			textChanged = false;
			setTitle("Conservation - ��־�༭��");
		}catch (IOException e) {
			JOptionPane.showMessageDialog(this, "��־����/����ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE);
		}
		/**
		 * Need For Complete
		 */
		//���������߼�
		//����Ƿ�����־����ô�����漰��������ϴ�������־
		if (submitArticle.getText().equals("������־")){
			//���뱾�������б�
			ArticleMonitor.addArticle(saveName);
			
			MainFrame.resetMainBoard();
			//����ǹ�����־����Ҫ�ϴ���������
			if (theArticle.authority == Authority.isPublic) {
				TransMonitor newTrans = new TransMonitor(new Transaction(TransType.add, ItemType.article, saveName, theArticle.title, theArticle.authority, -1));
				newTrans.setName("�洢����");
				try {
					newTrans.start();
				}catch (Exception e) {}
			}
		}else
		//������־���漰�����޸ĸ��¼�Ȩ�޸��£�
		if (submitArticle.getText().equals("�����޸�")){
			//Ȩ�ޱ仯
			if (originAuthority != theArticle.authority) {
				TransMonitor newTrans = new TransMonitor(new Transaction(TransType.changeAuthority, ItemType.article, saveName, theArticle.title, theArticle.authority, -1));
				newTrans.setName("�洢����");
				try {
					newTrans.start();
				}catch (Exception e) {}
			}else 
			//�����޸�
			if (originAuthority == Authority.isPublic && theArticle.authority == Authority.isPublic){
				TransMonitor newTrans = new TransMonitor(new Transaction(TransType.modify, ItemType.article, saveName, theArticle.title, theArticle.authority, -1));
				newTrans.setName("�洢����");
				try {
					newTrans.start();
				}catch (Exception e) {}
			}
		}
		
		return true;
	}
	
	//Check if Content Has Changed
	private void checkChange() {
		if (!nowContent.equals(scene.getText())) {
			nowContent = scene.getText();
			//preArticle.updateArticle(theArticle);
			updateArticle();
			Article temp = new Article();
			temp.updateArticle(theArticle);
			history.push(temp);
			if (!textChanged) {
				textChanged = true;
				setTitle("*Conservation - ��־�༭��");
			}
		}
	}
	
	//Redo the Last Modification
	private void redoChange() {
		if (!history.isEmpty()) {
			Article temp = history.pop();
			theArticle.updateArticle(temp);
			//preArticle.updateArticle(temp);
			updateUIFromArticle();
		}
	}
	
	//Change Font
	private void changeFont() {
		int style = 0;
		if (nowBold) style += Font.BOLD;
		if (nowItalic) style += Font.ITALIC;
		nowFontSize = Integer.valueOf(fontSize.getText().trim());
		Font f = new Font(nowFontName,style, nowFontSize);
		scene.setFont(f);
		scene.setBackground(nowBackColor);
		scene.setForeground(nowColor);
	}
	
	int message = 0;
	JDialog dialog;
	//Request for Save Dialog
	private int requestSave() {
		dialog = new JDialog(this, "����", true);
		dialog.setLayout(null);
		JButton yes = new JButton("��");
		yes.setBounds(30, 30, 60, 25);
		JButton no = new JButton("��");
		no.setBounds(100, 30, 60, 25);
		JButton cancel = new JButton("ȡ��");
		cancel.setBounds(170, 30, 60, 25);
		yes.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					message = 1;
					dialog.setVisible(false);
				}
			}
		);
		no.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					message = 2;
					dialog.setVisible(false);
				}
			}
		);
		cancel.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					message = 0;
					dialog.setVisible(false);
				}
			}
		);
		JLabel l1 = new JLabel("�����Ѿ��޸ģ��Ƿ񱣴�/������");
		l1.setBounds(30, 2, 200, 25);
		dialog.add(yes);dialog.add(no);dialog.add(cancel);dialog.add(l1);
		dialog.setBounds(this.getBounds().x+this.getBounds().width/2-150, this.getBounds().y+this.getBounds().height/2-50, 300, 100);
		dialog.setResizable(false);
		dialog.setVisible(true);
		return message;
	}
	
	int start = 0;
	JTextField toFind;
	//Search Dialog
	private void searchDialog() {
		dialog = new JDialog(this, "����", true);
		dialog.setLayout(null);
		JLabel l1 = new JLabel("����Ŀ��");
		l1.setBounds(40, 25, 70, 25);
		dialog.add(l1);
		toFind = new JTextField();
		toFind.setBounds(95, 25, 135, 25);
		dialog.add(toFind);
		JButton findNext = new JButton("��һ��");
		findNext.setBounds(40, 70, 80, 25);
		JButton done = new JButton("���");
		done.setBounds(150, 70, 80, 25);
		done.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dialog.setVisible(false);
				}
			}
		);
		start = 0;
		toFind.setText("");
		findNext.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String pattern = toFind.getText();
					if (pattern.length() > 0) {
						int nextPos = preArticle.content.indexOf(pattern, start);
						if (nextPos >= 0) {
							start = nextPos + 1;
							//dialog.setVisible(false);
							scene.select(nextPos, nextPos + pattern.length());
							scene.requestFocus();
						}else {
							start = 0;
							JOptionPane.showMessageDialog(null, "�Ѿ�����β", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
						}
					}
				}
			}
		);
		done.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dialog.setVisible(false);
				}
			}
		);
		dialog.add(findNext);
		dialog.add(done);
		dialog.setBounds(this.getBounds().x+this.getBounds().width/2-150, this.getBounds().y+this.getBounds().height/2-50, 280, 160);
		dialog.setResizable(false);
		dialog.setVisible(true);
	}
	
		JTextField toReplace;
	//Search Dialog
		private void replaceDialog() {
			dialog = new JDialog(this, "�滻", true);
			dialog.setLayout(null);
			JLabel l1 = new JLabel("����Ŀ��");
			l1.setBounds(40, 25, 70, 25);
			dialog.add(l1);
			toFind = new JTextField();
			toFind.setBounds(95, 25, 135, 25);
			dialog.add(toFind);
			JLabel l2 = new JLabel("�滻Ϊ");
			l2.setBounds(40, 55, 70, 25);
			dialog.add(l2);
			toReplace = new JTextField();
			toReplace.setBounds(95, 55, 135, 25);
			dialog.add(toReplace);
			
			JButton replace = new JButton("�滻");
			replace.setBounds(40, 100, 80, 25);
			JButton done = new JButton("���");
			done.setBounds(150, 100, 80, 25);
			done.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dialog.setVisible(false);
					}
				}
			);
			start = 0;
			toFind.setText("");
			toReplace.setText("");
			replace.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String pattern = toFind.getText();
						if (pattern.length() > 0) {
							String temp = scene.getText();
							temp = temp.replaceAll(pattern, toReplace.getText());
							scene.setText(temp);
							checkChange();
							JOptionPane.showMessageDialog(null, "�滻���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
						}
					}
				}
			);
			done.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dialog.setVisible(false);
					}
				}
			);
			dialog.add(replace);
			dialog.add(done);
			dialog.setBounds(this.getBounds().x+this.getBounds().width/2-150, this.getBounds().y+this.getBounds().height/2-50, 280, 180);
			dialog.setResizable(false);
			dialog.setVisible(true);
		}
}
