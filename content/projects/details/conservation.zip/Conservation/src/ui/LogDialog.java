package ui;

import trans.ConservationFactory;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class LogDialog extends JFrame{

	private JTextField username;
	private JPasswordField password;
	private JPanel close;
	private UIPanel btnLogin;
	public LogDialog() {
		init();
		UIUniversal.ToCenter(this);
	}
	private void init() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/Conservation.png");
		this.setIconImage(im);
		this.setSize(400, 300);
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"login_background.png"), false);
		username = new JTextField(20);
		username.setFont(new Font(null, Font.PLAIN, 16));
		username.setBounds(150, 90,200,30);
		username.setBorder(BorderFactory.createLineBorder(Color.white));
		password = new JPasswordField(20);
		password.setFont(new Font(null, Font.PLAIN, 16));
		password.setBounds(150, 160,200,30);
		password.setBorder(BorderFactory.createLineBorder(Color.white));
		this.add(username);this.add(password);
		close = new JPanel(){

			public void paintComponent(Graphics g) {
		        //URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(363, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		
		this.add(close);
		
		btnLogin = new UIPanel(100, 35, "login.png"){

			public void paintComponent(Graphics g) {
		        //URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "login.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"login.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		btnLogin.setLocation(150, 225);
		btnLogin.bindMouseListener(btnLogin);
		btnLogin.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					String userName = username.getText();
					String userPassword = new String(password.getPassword());
					ConservationFactory.doLogin(userName, userPassword);
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		
		this.add(btnLogin);
		/*
		btnRegister = new UIPanel(80, 25, "register.png"){
			public void paintComponent(Graphics g) {
		        //URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "register.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"register.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		btnRegister.setLocation(270, 230);
		btnRegister.bindMouseListener(btnRegister);
		btnRegister.addMouseListener(
			new MouseListener() {

				@Override
				public void mouseClicked(MouseEvent e) {
					ConservationFactory.showRegister();
				}

				@Override
				public void mouseEntered(MouseEvent e) {}

				@Override
				public void mouseExited(MouseEvent e) {}

				@Override
				public void mousePressed(MouseEvent e) {}

				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		this.add(btnRegister);*/
	}
}


