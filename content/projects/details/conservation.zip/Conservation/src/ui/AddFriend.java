package ui;

import global.NowPage;
import global.SkinParameter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import trans.ConservationFactory;
import trans.FriendMonitor;

@SuppressWarnings({ "unused", "serial" })
public class AddFriend extends JFrame{
	private JPanel close,mainSceneInner;
	private JTextField userName;
	private UIPanel search;
	private JScrollPane mainScene;
	
	public AddFriend() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/friend.png");
		this.setIconImage(im);
		this.setSize(600,450);
		this.setTitle("Conservation - ���Ӻ���");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"add_friend.png"), false);
		
		//�û���
		userName = new JTextField();
		userName.setBounds(15, 30, 500, 20);
		userName.setBorder(BorderFactory.createLineBorder(Color.white));
		add(userName);
		//������ť
		search = new UIPanel(20, 20, "search.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"search.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		search.setBounds(515,30,20,20);
		search.bindMouseListener(search);
		search.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					//�Ȼ�ȡ�����Ӻ���
					loadList();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		add(search);
		//�����
		mainSceneInner = new JPanel();
		mainSceneInner.setSize(580, 100);
		mainSceneInner.setLayout(null);
		Dimension d = new Dimension(580,100);
		mainSceneInner.setPreferredSize(d);
		mainScene = new JScrollPane(mainSceneInner, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainScene.setBounds(10, 60, 580, 370);
		add(mainScene);
		validate();

		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(563, 5, 32, 32);
		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		UIUniversal.ToCenter(this);
	}
	//������������û�
	private void loadList() {
		FriendMonitor.searchUser(userName.getText().trim());
		while (FriendMonitor.isWorking)
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if (mainSceneInner!= null)
			mainScene.remove(mainSceneInner);
		if (mainScene!=null)
			remove(mainScene);
		mainSceneInner = new JPanel();
		
		int height = 0;
		int friendNumber = FriendMonitor.int1;
		for (int i = friendNumber -1; i >= 0; --i) {
			JPanel userPane = new JPanel();
			userPane.setLayout(null);
			userPane.setBackground(Color.white);
			//��Сλ��
			int itemWidth = 600;
			int itemHeight = 140;
			int x = 0;
			int y = height;
			userPane.setBounds(x, y, itemWidth, itemHeight);
			
			//�û�ͷ��
			JLabel imgShow = new JLabel();
			//width=170 height=120 
			int showWidth = 100, showHeight = 100;
			try {
				FileInputStream src = new FileInputStream(new File(System.getProperty("user.dir")+"/tmp/"+i+".png"));
				BufferedImage sourceImg = ImageIO.read(src);
				showWidth = sourceImg.getWidth();
				showHeight = sourceImg.getHeight();
				src.close();
				if (showHeight > 100) {
					showWidth = 100*showWidth/showHeight;
					showHeight = 100;
				}
				if (showHeight < 100) {
					showWidth = 100*100/showHeight;
					showHeight = 100;
				}
				if (showWidth < 100) {
					showHeight = 100 * 100/showWidth;
					showWidth = 100;
				}
			}catch (Exception e) {	
			}
			imgShow.setText("<html><img src='file:/"+System.getProperty("user.dir")+"/tmp/"+i+".png"+"' width="+showWidth+" height="+showHeight+" /></html>");
			JPanel frame = new JPanel();
			frame.setLayout(null);
			frame.setBounds(20, 20, 100, 100);
			imgShow.setBounds((100-showWidth)/2, (100-showHeight)/2, showWidth, showHeight);
			
			final int userId = FriendMonitor.intResult1.get(i);
			
			frame.add(imgShow);
			//System.out.println(imgShow.getWidth()+" "+imgShow.getHeight());
			userPane.add(frame);
			
			//�û���
			JLabel userName = new JLabel(FriendMonitor.strResult1.get(i));
			userName.setBounds(160, 20, 500, 20);
			userName.setForeground(SkinParameter.itemTitle);
			userName.setFont(new Font(null, Font.BOLD, 12));
			userPane.add(userName);
			
			//�û����
			JLabel userIntroduction = new JLabel("<html>"+FriendMonitor.strResult2.get(i)+"</html>");
			userIntroduction.setBounds(135, 30, 400, 100);
			userIntroduction.setForeground(SkinParameter.itemContent);
			userIntroduction.setFont(new Font(null, Font.PLAIN, 12));
			userPane.add(userIntroduction);
			
			//�û��Ա�
			final boolean gender = FriendMonitor.boolResult1.get(i).booleanValue();
			JPanel isGirl = new JPanel(){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+(gender==true?"female.png":"male.png"));
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			isGirl.setBounds(135, 20, 16, 16);
			userPane.add(isGirl);
			
			//��Ϊ����
			UIPanel confirmFriend = new UIPanel(80, 30, "add_friend_btn.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"add_friend_btn.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			confirmFriend.bindMouseListener(confirmFriend);
			confirmFriend.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						FriendMonitor.addFriend(userId);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			confirmFriend.setBounds(480, 100, 80, 30);
			userPane.add(confirmFriend);
			
			//����
			UIPanel leaveMessage = new UIPanel(50, 25, "leave_message.png"){
				public void paintComponent(Graphics g) {
					ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"leave_message.png");
			        g.drawImage(img.getImage(),0,0,null);
			    }
			};
			
			final String toUserName = FriendMonitor.strResult1.get(i);
			
			leaveMessage.bindMouseListener(leaveMessage);
			leaveMessage.addMouseListener(
				new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e) {
						SendMessage sendMessage = new SendMessage(userId,toUserName);
						sendMessage.setVisible(true);
					}
					@Override
					public void mouseEntered(MouseEvent e) {}
					@Override
					public void mouseExited(MouseEvent e) {}
					@Override
					public void mousePressed(MouseEvent e) {}
					@Override
					public void mouseReleased(MouseEvent e) {}
				}
			);
			leaveMessage.setBounds(420, 102, 50, 25);
			userPane.add(leaveMessage);
			
			//���ӻ������
			mainSceneInner.add(userPane);
			height += 150;
		}
		
		mainSceneInner.setSize(580, height);
		mainSceneInner.setLayout(null);
		Dimension d = new Dimension(580,height);
		mainSceneInner.setPreferredSize(d);
		mainScene = new JScrollPane(mainSceneInner, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainScene.setBounds(10, 60, 580, 370);
		add(mainScene);
		validate();
	}
}
