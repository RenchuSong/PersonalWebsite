package ui;

import global.SkinParameter;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import trans.DownloadMonitor;

@SuppressWarnings("serial")
public class WebPhotoViewer extends JFrame implements Runnable{
	private JPanel close;
	private JPanel frameImage;
	private JLabel showImage, imageName, imageTime;
	private String photoName, fileName, oriFileName;
	private long photoTime;
	private JButton transfer;
	private int fromId;
	private int newsId;
	
	public WebPhotoViewer(int newsId2,String photoName2, String fileName2,String oriFileName2,long photoTime2, int fromId2) {
		this.photoName = photoName2;
		this.photoTime = photoTime2;
		this.fileName = fileName2;
		this.fromId = fromId2;
		this.newsId=newsId2;
		this.oriFileName = oriFileName2;
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/photo.png");
		this.setIconImage(im);
		this.setSize(600,440);
		this.setTitle("Conservation - ��Ƭ�鿴��");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"photo_viewer.png"), false);
		
		
		//��Ƭ����
		frameImage = new JPanel();
		frameImage.setBounds(60, 60, 480, 300);
		frameImage.setLayout(null);
		frameImage.setBackground(SkinParameter.photoFrameBackground);
		showImage = new JLabel();
		frameImage.add(showImage);
		this.add(frameImage);
		
		//��Ƭ����
		imageName = new JLabel();
		imageName.setForeground(SkinParameter.photoViewerTitle);
		imageName.setFont(new Font(null, Font.BOLD, 16));
		imageName.setBounds(60, 370, 480, 20);
		this.add(imageName);
		
		//��Ƭʱ��
		imageTime = new JLabel();
		imageTime.setForeground(SkinParameter.photoViewerContent);
		imageTime.setFont(new Font(null, Font.PLAIN, 12));
		imageTime.setBounds(60, 400, 400, 20);
		this.add(imageTime);
		
		
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(563, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		
		//ת�ذ�ť
		transfer = new JButton("ת��");
		transfer.setBackground(new Color(26, 105, 173));
		transfer.setForeground(Color.white);
		transfer.setBounds(480,400,60,20);
		transfer.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					//seletePhoto();
					DownloadMonitor.downloadPhoto(newsId,photoName , fileName, oriFileName, fromId);
				}
			}
		);
		this.add(transfer);
		
		this.setVisible(true);
	}
	
	public void showPhoto() {
		imageName.setText(fileName);
		imageTime.setText("�ϴ�ʱ�䣺"+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format(photoTime));
		
		int showWidth = 480, showHeight = 300;
		try {
			BufferedImage sourceImg = ImageIO.read(new FileInputStream(new File(photoName)));
			showWidth = sourceImg.getWidth();
			showHeight = sourceImg.getHeight();
			if (showHeight > 300) {
				showWidth = 300*showWidth/showHeight;
				showHeight = 300;
			}
			
			if (showWidth > 480) {
				showHeight = 480*showHeight/showWidth;
				showWidth = 480;
			}
		}catch (Exception e) {	
		}
		showImage.setText("<html><img src='file:/"+photoName+"' width="+showWidth+" height="+showHeight+" /></html>");
		showImage.setBounds((480-showWidth)/2, (300-showHeight)/2, showWidth, showHeight);
		
	}
	
	public void run() {
		int x = this.getX() + 550;
		int dx = 100;
		int y = this.getY();
		this.setLocation(x , y);
		this.setVisible(true);
		for (int i = 0; i< 10; ++i) {
			x -= dx;
			dx -= 10;
			this.setLocation(x , y);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			}
		}
		this.showPhoto();
	}
	/*
	public static void main(String[] args) {
		new PhotoViewer();
	}*/
}
