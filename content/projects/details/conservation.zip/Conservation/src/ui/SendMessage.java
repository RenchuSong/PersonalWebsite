package ui;

import global.Authority;
import global.Photo;
import global.SkinParameter;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import trans.ConservationFactory;
import trans.MessageMonitor;
import trans.PhotoMonitor;
import trans.VideoMonitor;

//��Ƭ�ϴ���
@SuppressWarnings({ "serial", "unused" })
public class SendMessage extends JFrame{
	private JPanel close;
	private JLabel toName;
	private JTextArea content;
	private JButton selBtn,upload, cancel;
	private JCheckBox share;
	JFileChooser fileChooser;
	
	public String toUserName;
	public int toUserId;
	
	public SendMessage(int userId, String userName) {
		this.toUserId = userId;
		this.toUserName = userName;
		
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/message.png");
		this.setIconImage(im);
		this.setSize(500,250);
		this.setTitle("Conservation - ����");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"send_message.png"), false);
		
		
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(463, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		reload();
	}

	public void reload(){
		JLabel title = new JLabel("���Ը�");
		title.setBounds(20, 20, 200, 20);
		title.setFont(new Font(null, Font.BOLD, 14));
		title.setForeground(SkinParameter.photoUploaderTitle);
		this.add(title);
		
		toName = new JLabel(this.toUserName);
		toName.setBounds(90, 20, 200, 20);
		toName.setForeground(SkinParameter.itemContent);
		this.add(toName);
		
		JLabel message = new JLabel("��������");
		message.setBounds(20, 52, 80, 14);
		message.setFont(new Font(null, Font.PLAIN, 14));
		message.setForeground(SkinParameter.photoUploaderContent);
		this.add(message);
		
		content = new JTextArea();
		content.setBounds(90, 50, 360, 130);
		content.setLineWrap(true);
		this.add(content);
		
		upload = new JButton("����");
		upload.setBackground(new Color(26, 105, 173));
		upload.setForeground(Color.white);
		upload.setBounds(90,200,60,20);
		
		cancel = new JButton("ȡ��");
		cancel.setBackground(new Color(26, 105, 173));
		cancel.setForeground(Color.white);
		cancel.setBounds(180,200,60,20);
		cancel.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			}
		);
		upload.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					uploadMessage();
				}
			}
		);
		//===============
		
		//===============
		this.add(upload);this.add(cancel);
		
	}
	public void uploadMessage() {
		try {
			String message = this.content.getText().trim();
			if (message.length() < 1) {
				JOptionPane.showMessageDialog(this, "�������ݲ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
				return;
			}
			//�ĳ�һ���߳�
			MessageMonitor.addMessage(this.toUserId, message);
		}catch (Exception e) {;
			JOptionPane.showMessageDialog(this, "�����ύʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE);
		} 
		this.dispose();
	}
}
