package ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class UIUniversal {
	private static UIUniversal instance = new UIUniversal();
	public static String skinPath;
	
	private UIUniversal() {
		init();
	}
	
	public static UIUniversal getInstance() {
		return instance;
	}
	
	//ȫ�ֳ�ʼ��
	private void init() {
		skinPath = "";
		try {
			BufferedReader fin = new BufferedReader(new FileReader(System.getProperty("user.dir")+"/config/cache_skin"));
			skinPath = fin.readLine();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e.toString(), "����", JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e.toString(), "����", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	//��ȡƤ��·��
	public String getSkinPath() {
		return System.getProperty("user.dir")+"/skin/"+skinPath + "/";
	}
	
	//����Ƥ��·��
	public void setSkinPath(String newPath) {
		skinPath = newPath;
	}
	
	//���������õ���Ļ����
	public static void ToCenter(JFrame frame)
	  {
	      //---------------------------���ô��ھ���----------------------------------------------------------
	        int windowWidth = frame.getWidth();                    //��ô��ڿ�
	        int windowHeight = frame.getHeight();                  //��ô��ڸ�
	        Toolkit kit = Toolkit.getDefaultToolkit();             //���幤�߰�
	        Dimension screenSize = kit.getScreenSize();            //��ȡ��Ļ�ĳߴ�
	        int screenWidth = screenSize.width;                    //��ȡ��Ļ�Ŀ�
	        int screenHeight = screenSize.height;                  //��ȡ��Ļ�ĸ�
	        frame.setLocation(screenWidth/2-windowWidth/2, screenHeight/2-windowHeight/2);//���ô��ھ�����ʾ
	        //------------------------------------------------------------------------------------------------
	  }
	
	//���ñ���ͼƬ
	public static void setBackImage(JFrame frame, ImageIcon icon, boolean isAutoSize) {
		if (frame == null || icon == null) return;
		Container pane = frame.getContentPane();
		((JPanel) pane).setOpaque(false);
		JLayeredPane layerp = frame.getLayeredPane();
		Component[] coms = layerp.getComponentsInLayer(new Integer(Integer.MIN_VALUE));
		if (coms.length > 0)
			for (Component com: coms)
				layerp.remove(com);
		JLabel lab = new JLabel(icon);
		if (isAutoSize)
			icon.setImage(icon.getImage().getScaledInstance(frame.getSize().width, frame.getSize().height, Image.SCALE_SMOOTH));
		lab.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		layerp.add(lab, new Integer(Integer.MIN_VALUE));
	}
}
