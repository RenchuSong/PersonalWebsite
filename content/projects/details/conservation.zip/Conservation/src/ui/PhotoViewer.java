package ui;

import global.SkinParameter;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import trans.PhotoMonitor;

@SuppressWarnings("serial")
public class PhotoViewer extends JFrame implements Runnable{
	public int photoIndex = 0;
	private JPanel close;
	private UIPanel pre,next;
	private JPanel frameImage;
	private JLabel showImage, imageName, imageTime;
	
	public PhotoViewer() {
		Toolkit tool=this.getToolkit();
		Image im = tool.getImage(System.getProperty("user.dir")+"/skin/global/photo.png");
		this.setIconImage(im);
		this.setSize(600,440);
		this.setTitle("Conservation - ��Ƭ�鿴��");
		String skinPath = UIUniversal.getInstance().getSkinPath();
		this.setLayout(null);
		this.setUndecorated(true);
		UIUniversal.ToCenter(this);
		UIUniversal.setBackImage(this, new ImageIcon(skinPath+"photo_viewer.png"), false);
		
		//ǰһ����ť
		pre = new UIPanel(48, 48, "previous_photo.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"previous_photo.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		pre.setBounds(5, 160, 48, 48);
		//stop.bindMouseListener(stop);
		pre.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					prePhoto();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		this.add(pre);
		//��һ����ť
		next = new UIPanel(48, 48, "next_photo.png"){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"next_photo.png");
		        g.drawImage(img.getImage(),0,0,null);
		    }
		};
		next.setBounds(547, 160, 48, 48);
		//stop.bindMouseListener(stop);
		next.addMouseListener(
			new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					nextPhoto();
				}
				@Override
				public void mouseEntered(MouseEvent e) {}
				@Override
				public void mouseExited(MouseEvent e) {}
				@Override
				public void mousePressed(MouseEvent e) {}
				@Override
				public void mouseReleased(MouseEvent e) {}
			}
		);
		this.add(next);
		
		//��Ƭ����
		frameImage = new JPanel();
		frameImage.setBounds(60, 60, 480, 300);
		frameImage.setLayout(null);
		frameImage.setBackground(SkinParameter.photoFrameBackground);
		showImage = new JLabel();
		frameImage.add(showImage);
		this.add(frameImage);
		
		//��Ƭ����
		imageName = new JLabel();
		imageName.setForeground(SkinParameter.photoViewerTitle);
		imageName.setFont(new Font(null, Font.BOLD, 16));
		imageName.setBounds(60, 370, 480, 20);
		this.add(imageName);
		
		//��Ƭʱ��
		imageTime = new JLabel();
		imageTime.setForeground(SkinParameter.photoViewerContent);
		imageTime.setFont(new Font(null, Font.PLAIN, 12));
		imageTime.setBounds(60, 400, 400, 20);
		this.add(imageTime);
		
		
		//�رհ�ť
		close = new JPanel(){
			public void paintComponent(Graphics g) {
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,null);
		         }
		    };
		close.setBounds(563, 5, 32, 32);

		//close.addMouseListener(new closeListenser(close));
		close.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
		        ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				//URL url = getClass().getResource(UIUniversal.getInstance().getSkinPath() + "close.png");
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),0,0,close);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-64,0,close);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				Graphics g = close.getGraphics();
				ImageIcon img = new ImageIcon(UIUniversal.getInstance().getSkinPath()+"close.png");
		        g.drawImage(img.getImage(),-32,0,close);
			}
		});
		this.add(close);
		this.setVisible(true);
	}
	
	public void showPhoto() {
		imageName.setText(PhotoMonitor.photoList.get(photoIndex).getPhotoName());
		imageTime.setText("�ϴ�ʱ�䣺"+new java.text.SimpleDateFormat("yyyy��MM��dd�� HH:mm:ss").format(Long.parseLong(PhotoMonitor.photoList.get(photoIndex).getFileName().substring((System.getProperty("user.dir")+"/content/photo/").length(), PhotoMonitor.photoList.get(photoIndex).getFileName().length() - 4))));
		
		int showWidth = 480, showHeight = 300;
		try {
			BufferedImage sourceImg = ImageIO.read(new FileInputStream(new File(PhotoMonitor.photoList.get(photoIndex).getFileName())));
			showWidth = sourceImg.getWidth();
			showHeight = sourceImg.getHeight();
			if (showHeight > 300) {
				showWidth = 300*showWidth/showHeight;
				showHeight = 300;
			}
			
			if (showWidth > 480) {
				showHeight = 480*showHeight/showWidth;
				showWidth = 480;
			}
		}catch (Exception e) {	
		}
		showImage.setText("<html><img src='file:/"+PhotoMonitor.photoList.get(photoIndex).getFileName()+"' width="+showWidth+" height="+showHeight+" /></html>");
		showImage.setBounds((480-showWidth)/2, (300-showHeight)/2, showWidth, showHeight);
		
	}
	
	private void prePhoto() {
		photoIndex--;
		if (photoIndex < 0) photoIndex = PhotoMonitor.photoList.size() - 1;
		showPhoto();
	}
	
	private void nextPhoto() {
		photoIndex++;
		if (photoIndex >= PhotoMonitor.photoList.size()) photoIndex = 0;
		showPhoto();
	}
	
	public void run() {
		int x = this.getX() + 550;
		int dx = 100;
		int y = this.getY();
		this.setLocation(x , y);
		this.setVisible(true);
		for (int i = 0; i< 10; ++i) {
			x -= dx;
			dx -= 10;
			this.setLocation(x , y);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			}
		}
		this.showPhoto();
	}
	/*
	public static void main(String[] args) {
		new PhotoViewer();
	}*/
}
