import global.Article;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import javax.swing.JOptionPane;

import trans.Account;
import trans.ConservationFactory;
import ui.ArticleEditor;

@SuppressWarnings("unused")
public class Conservation {
	public static void main(String[] args) {		
		try {
			ConservationFactory.startUp();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.toString(), "����", JOptionPane.ERROR_MESSAGE);
		}
	}
}
